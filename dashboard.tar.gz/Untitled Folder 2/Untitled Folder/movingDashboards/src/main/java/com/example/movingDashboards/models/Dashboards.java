package com.example.movingDashboards.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
@Document
public class Dashboards {

    @Id
    private  String id ;

    @Indexed(unique = true )
    private String name ;

    private  String description ;

    private LocalDateTime localDateTime ;

    private boolean deleted ;

    // List qe mban Id e widget One to many relationship
    List<String> widgetIdList ;

    LocalDateTime lastOpened ;

    // Mban referencen per connection per 1 dashboard specifik
    // Nqs coonection is down ath nga front endi do te behet nje request me id specifike per te ndrysuar conection
    private  boolean connectionCheck ;

    public Dashboards( @NonNull  String name, String description, @NonNull LocalDateTime localDateTime, @NonNull boolean deleted, LocalDateTime lastOpened, boolean connectionCheck ){
        this.name = name ;
        this.description = description ;
        this.localDateTime = localDateTime ;
        this.deleted = deleted ;
        this.lastOpened = lastOpened ;
        this.connectionCheck = connectionCheck ;
    }

    public Dashboards( @NonNull  String name, String description, @NonNull LocalDateTime localDateTime, @NonNull boolean deleted, List<String> widgetIdList ,  LocalDateTime lastOpened, boolean connectionCheck  ){
        this.name = name ;
        this.description = description ;
        this.localDateTime = localDateTime ;
        this.deleted = deleted ;
        this.widgetIdList = widgetIdList ;
        this.lastOpened = lastOpened;
        this.connectionCheck = connectionCheck ;
    }
}
