package com.example.movingDashboards.dtos;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
public class DashboardPostDto {

    private String name ;

    private  String description ;

    public DashboardPostDto(String name, String description) {
        this.name = name;
        this.description = description;
    }
}
