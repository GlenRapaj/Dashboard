package com.example.movingDashboards.repos;

import com.example.movingDashboards.models.Dashboards;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface DashboardsRepo extends MongoRepository<Dashboards, String> {

    public Optional<Dashboards> findByName(String name);

    @Query( value = " { $or: [ {'deleted' :?0} ]} ")
    Page<Dashboards> findAllNotDeleted(boolean deleted, Pageable pageable  );  // List<Dashboards> , Sort sort

    @Query( value = " { $and: [  {  $or:[ {'name' :/?0/}, {'name' :?0} ] },  {'deleted' : false}  ] } " )
    Page<Dashboards> filterByDashboardName(String name, Pageable paging );  // Pageable pageable  // Page<Tutorial> //  Slice<T>

    @Query( value = " { $or: [ {'deleted' : true} ]} " )
    List<Dashboards> findDeletedDashboards( );

    @Query( value = " {  $and: [  {'deleted' : ?0 },   { lastOpened: { $ne: ?1 } }  ] }  ")
    Page<Dashboards> lastThreeOpened(boolean deleted, LocalDateTime localDate, Pageable pageable  );

}
