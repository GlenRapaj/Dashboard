package com.example.movingDashboards.services;

import com.example.movingDashboards.models.Dashboards;
import com.example.movingDashboards.models.Widgets;

import java.util.List;
import java.util.Optional;

public interface WidgetsService {

    public boolean getWidgetFromName( String name );

    public Widgets addWidget(Widgets widgets );

    public List<Widgets> getAllWidgets(  String dashboardId );

    public void saveWidgetPosition( List<Widgets> widgetWithCordinates );

    public void hardDelete( String id );

    public Optional<Widgets> getOneWidget(String id );

    public void modifiedWidget( Widgets widgetDto );
    // public void sendDataToFrontEnd(  ) throws InterruptedException ;

    public void changeDateFilterStartingInterval( String id, long value  );

    public Optional<Widgets> nameWidgetExistence(String name, String id );

    public void singleWidgetData(String widgetId, String dashboardId) ;
}
