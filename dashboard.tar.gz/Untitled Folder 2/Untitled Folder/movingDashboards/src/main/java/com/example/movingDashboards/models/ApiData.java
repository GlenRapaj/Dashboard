package com.example.movingDashboards.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Document
public class ApiData {

    // Number of devices 200

    private String id;

    private Double air;
    private Double temp;
    private Double co2;
    private Double rain;

    private String nameFilter;

    private float longtitude;
    private float langtitude;

    public ApiData(double air, double temp, double co2, double rain, String nameFilter, float longtitude, float langtitude) {
        this.air = air;
        this.temp = temp;
        this.co2 = co2;
        this.rain = rain;
        this.nameFilter = nameFilter;
        this.longtitude = longtitude;
        this.langtitude = langtitude;
    }

    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof ApiData)) return false;
        final ApiData other = (ApiData) o;
        if (!other.canEqual((Object) this)) return false;
        final Object this$id = this.getId();
        final Object other$id = other.getId();
        if (this$id == null ? other$id != null : !this$id.equals(other$id)) return false;
        if (Double.compare(this.getAir(), other.getAir()) != 0) return false;
        if (Double.compare(this.getTemp(), other.getTemp()) != 0) return false;
        if (Double.compare(this.getCo2(), other.getCo2()) != 0) return false;
        if (Double.compare(this.getRain(), other.getRain()) != 0) return false;
        final Object this$nameFilter = this.getNameFilter();
        final Object other$nameFilter = other.getNameFilter();
        if (this$nameFilter == null ? other$nameFilter != null : !this$nameFilter.equals(other$nameFilter))
            return false;
        if (Float.compare(this.getLongtitude(), other.getLongtitude()) != 0) return false;
        if (Float.compare(this.getLangtitude(), other.getLangtitude()) != 0) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof ApiData;
    }

    /*
    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $id = this.getId();
        result = result * PRIME + ($id == null ? 43 : $id.hashCode());
        final long $air = Double.doubleToLongBits(this.getAir());
        result = result * PRIME + (int) ($air >>> 32 ^ $air);
        final long $temp = Double.doubleToLongBits(this.getTemp());
        result = result * PRIME + (int) ($temp >>> 32 ^ $temp);
        final long $co2 = Double.doubleToLongBits(this.getCo2());
        result = result * PRIME + (int) ($co2 >>> 32 ^ $co2);
        final long $rain = Double.doubleToLongBits(this.getRain());
        result = result * PRIME + (int) ($rain >>> 32 ^ $rain);
        final Object $nameFilter = this.getNameFilter();
        result = result * PRIME + ($nameFilter == null ? 43 : $nameFilter.hashCode());
        result = result * PRIME + Float.floatToIntBits(this.getLongtitude());
        result = result * PRIME + Float.floatToIntBits(this.getLangtitude());
        return result;
    }
     */

    public int hashCode() {

        if( this.air != null ){
            return this.air.hashCode();
        }else if( this.temp != null ){
            return this.temp.hashCode();
        }else if( this.co2 != null ){
            return this.co2.hashCode();
        }else{
            return this.rain.hashCode();
        }

    }

}
