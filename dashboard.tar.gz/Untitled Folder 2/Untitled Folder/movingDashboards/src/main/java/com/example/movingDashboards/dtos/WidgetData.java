package com.example.movingDashboards.dtos;

import com.example.movingDashboards.models.InformationData;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
public class WidgetData {

    // widget id
    private  String id ;
    private List<InformationData> informationDataList ;

    public WidgetData( String id, List<InformationData> informationDataList  ){
        this.id = id ;
        this.informationDataList = informationDataList ;
    }
}
