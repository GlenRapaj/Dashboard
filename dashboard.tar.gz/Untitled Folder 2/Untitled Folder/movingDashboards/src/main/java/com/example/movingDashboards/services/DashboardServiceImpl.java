package com.example.movingDashboards.services;

import com.example.movingDashboards.models.Dashboards;
import com.example.movingDashboards.repos.DashboardsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service("dashboardService")
public class DashboardServiceImpl implements  DashboardService{

    @Autowired
    private MongoTemplate mt;

    private DashboardsRepo dashboardsRepo ;

    @Autowired
    public DashboardServiceImpl(DashboardsRepo dashboardsRepo ){
        this.dashboardsRepo = dashboardsRepo ;
    }


    public String saveDashboards(Dashboards dashboards ){
        Optional<Dashboards> optionalDashboard = this.dashboardsRepo.findByName( dashboards.getName() );

        if( optionalDashboard.isPresent() ){
            return "Object is allredy in DB.";
        }
        
         // dashboards.setLastOpened( LocalDateTime.of(0, 1, 1, 0, 0 ) ) ;
        this.dashboardsRepo.save( dashboards );
        return "" ;
    }

    public Page<Dashboards> getAllDashboards(int page, int size ){

        // fillon nga 0
        Pageable paging = PageRequest.of(page, size, Sort.by( "localDateTime" ).descending() );
        // Sort sortOrder = Sort.by("localDateTime");

        //Query query = new Query();
        //query.addCriteria(Criteria.where("deleted").is(false));
        //return mt.find(query, Dashboards.class );
        return  this.dashboardsRepo.findAllNotDeleted(false, paging);
    }

    public  boolean deleteDashboard( String id ){
        Optional<Dashboards> optionalDashboard = this.dashboardsRepo.findById(id) ;

        if( optionalDashboard.isPresent() ){
            Dashboards dashboard = optionalDashboard.get();
            dashboard.setDeleted( true );
            dashboard.setLocalDateTime(LocalDateTime.now());

            this.dashboardsRepo.save( dashboard );
        }
        return false ;
    }

    public  void rvertDelete( String id ){
        Optional<Dashboards> optionalDashboard = this.dashboardsRepo.findById(id) ;

        if( optionalDashboard.isPresent() ){
            Dashboards dashboard = optionalDashboard.get();
            dashboard.setDeleted( false );
            dashboard.setLocalDateTime(LocalDateTime.now());

            this.dashboardsRepo.save( dashboard );
        }
    }

    public Dashboards getOneDashboard( String id ){
        Optional<Dashboards> optionalDashboard = this.dashboardsRepo.findById(id) ;

        if( optionalDashboard.isPresent() ){
            Dashboards dashboard = optionalDashboard.get();
            return dashboard ;
        }
        return null;
    }

    public Dashboards getOneDashboardByName( String name ){
        Optional<Dashboards> optionalDashboard = this.dashboardsRepo.findByName(name) ;

        if( optionalDashboard.isPresent() ){
            Dashboards dashboard = optionalDashboard.get();
            return dashboard ;
        }
        return null;
    }

    public boolean modyfieDashboard( Dashboards dashboard ){
        Optional<Dashboards> optDashboard = this.dashboardsRepo.findById( dashboard.getId() );

        if( optDashboard.isPresent() ){
            dashboard.setWidgetIdList( optDashboard.get().getWidgetIdList() );
            dashboard.setLastOpened(  optDashboard.get().getLastOpened() );
            dashboard.setConnectionCheck( optDashboard.get().isConnectionCheck() );
            this.dashboardsRepo.save(dashboard);
            return true ;
        }
        return false ;
    }

    public boolean setDashboardOpened( String id ){
        Optional<Dashboards> optDashboard = this.dashboardsRepo.findById( id );

        if( optDashboard.isPresent() ){
            Dashboards dashboard = optDashboard.get();

            dashboard.setLastOpened( LocalDateTime.now() );
            this.dashboardsRepo.save(dashboard);
            return true ;
        }
        return false ;
    }

    public Page<Dashboards> getAllDashboards( ){
        Pageable paging = PageRequest.of(0, 3, Sort.by( "lastOpened" ).descending() );
        return  this.dashboardsRepo.lastThreeOpened(false, LocalDateTime.of(0, 1, 1, 0, 0 ) , paging);
    }

    public boolean  hardDelete( String id ){
        Optional<Dashboards> optDashboard = this.dashboardsRepo.findById(id);

        if( optDashboard.isPresent() ){

            if(optDashboard.get().getWidgetIdList().size() > 0  ){
                return true ;
            }
            this.dashboardsRepo.deleteById(id);
        }
        return false ;
    }

    public Optional<Dashboards> getOneDashboardById(String id ){
        return this.dashboardsRepo.findById( id ) ;
    }

    public List<Dashboards> listDeletedDashboards(){
        return this.dashboardsRepo.findDeletedDashboards();
    }

    public  Page<Dashboards> filterDashboards( String name, int page, int size ){

        Pageable paging = PageRequest.of(page, size, Sort.by( "localDateTime" ).descending() );
       return this.dashboardsRepo.filterByDashboardName( name, paging );
    }

    public void setDashboardConnection( String dashboardId, Boolean newConnectionStatus ){
        Optional<Dashboards> optDashboard = this.dashboardsRepo.findById( dashboardId );

        if( optDashboard.isPresent() ){
            Dashboards dashboard = optDashboard.get();
            dashboard.setConnectionCheck( newConnectionStatus );
            this.dashboardsRepo.save( dashboard );
        }
    }

}
