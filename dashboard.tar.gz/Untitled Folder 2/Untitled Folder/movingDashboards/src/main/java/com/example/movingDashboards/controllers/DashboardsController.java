package com.example.movingDashboards.controllers;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.example.movingDashboards.config.HandledException;
import com.example.movingDashboards.dtos.DashboardPostDto;
import com.example.movingDashboards.dtos.DashboardTableDto;
import com.example.movingDashboards.models.Dashboards;
import com.example.movingDashboards.services.DashboardService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/dashboards/")
@CrossOrigin("*")
public class DashboardsController {

    private DashboardService dashboardService ;

    public  DashboardsController( @Qualifier("dashboardService") DashboardService dashboardService ){
        this.dashboardService = dashboardService ;
    }


    @ResponseStatus(HttpStatus.OK)
    @PostMapping("add-dashboard")
    public void addNewDashboard(@RequestBody DashboardPostDto dashboardPostDto ){
        if( this.checkRequiredFields( dashboardPostDto.getName() )){
            throw new HandledException("Name can not be blank.") ;
        }

        List<String> widgetIdList = new ArrayList<>();
        Dashboards dashboard = new Dashboards(  dashboardPostDto.getName(), dashboardPostDto.getDescription(), LocalDateTime.now(),
                false, widgetIdList, LocalDateTime.of(0, 1, 1, 0, 0 ), false );

        String ans = this.dashboardService.saveDashboards( dashboard ) ;

        if( !ans.isBlank() ){
            throw new HandledException( ans ) ;
        }
    }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("all-dashboards")
    public Page<Dashboards> getAllDashboards(@RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "3") int size ){  // all-dashboards?page=0&size=3

        Page<Dashboards> dashboards =  this.dashboardService.getAllDashboards(page, size );
        return dashboards ;
    }

    @ResponseStatus(HttpStatus.OK)
    @DeleteMapping("delete-dashboard/{id}")
    public void deleteDashboard(@PathVariable("id") String id ){
        this.dashboardService.deleteDashboard(id);
    }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("revert-delete/{id}")
    public void rvertDelete( @PathVariable("id") String id ){
        this.dashboardService.rvertDelete( id );
    }


    @ResponseStatus(HttpStatus.OK)
    @GetMapping("one-element/{id}")
    public DashboardTableDto getOneDashboard( @PathVariable("id") String id ){
        Dashboards dashboard = this.dashboardService.getOneDashboard(id);

        if( dashboard == null ){
            throw new HandledException("Dashboard not found.") ;
        }
        return new DashboardTableDto( dashboard.getId() , dashboard.getName(), dashboard.getDescription() ) ;
    }

    @ResponseStatus(HttpStatus.OK)
    @PutMapping("modyfie-dashboard/{id}")
    public void modyfieDashboard( @PathVariable("id") String id, @RequestBody DashboardTableDto dashboardTableDto ){

        if( this.checkRequiredFields( dashboardTableDto.getName() ) ){
            throw new HandledException("Name of Dashboard can not be blank.") ;
        }

        Dashboards dashboard = new Dashboards(  dashboardTableDto.getName(), dashboardTableDto.getDescription(),  LocalDateTime.now() , false, LocalDateTime.of(0, 1, 1, 0, 0 ) , false);
        dashboard.setId( id );
        boolean ans = this.dashboardService.modyfieDashboard( dashboard );

        if( !ans ){
            throw new HandledException(" Dashboard not found. Can not update.") ;
        }
    }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("filter-dashboards/{name}")
    public Page<Dashboards> filterDashboards(@PathVariable("name") String name, @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "3") int size ){

        return this.dashboardService.filterDashboards( name, page, size );

    }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("delete-list")
    public List<DashboardTableDto> listDeleted(){
        List<Dashboards> dashboards = this.dashboardService.listDeletedDashboards();

        for( int i = 0 ; i < dashboards.size() - 1 ; i++ ){
            for ( int j = i + 1 ; j < dashboards.size() ; j++ ){
                if( dashboards.get(i).getLocalDateTime().isBefore( dashboards.get(j).getLocalDateTime() ) ){
                    Dashboards temp = dashboards.get(i) ;
                    dashboards.set( i , dashboards.get(j) );
                    dashboards.set( j , temp );
                }
            }
        }
        List<DashboardTableDto> dashboardList = new ArrayList<>();

        for(Dashboards d : dashboards){
            dashboardList.add( new DashboardTableDto( d.getId(), d.getName(), d.getDescription() ) ) ;
        }
        return dashboardList ;
    }

    @ResponseStatus(HttpStatus.OK)
    @DeleteMapping("hard-delete-dashboard/{id}")
    public boolean HardDeleteDashboard( @PathVariable("id") String id ){
        boolean ans = this.dashboardService.hardDelete( id );
        
        if(ans){
            throw new HandledException("Dashboard can not be deleted. Remove Widgets first.") ;
        }
        return true;
    }

    @GetMapping("dashboard-name/{name}")
    public DashboardTableDto getOneDashboardByName(@PathVariable("name") String name ){
        Dashboards dashboard = this.dashboardService.getOneDashboardByName( name );

        if( dashboard == null ){
            throw new HandledException(" Dashboard not found.") ;
        }

        return new DashboardTableDto( dashboard.getId() , dashboard.getName(), dashboard.getDescription() ) ;
    }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("opened-dashboard/{id}")
    public void setDashboardOpened( @PathVariable("id") String id ){ // , @RequestBody DashboardTableDto dashboardTableDto
        boolean ans = this.dashboardService.setDashboardOpened( id );
    }

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("three-last")
    public Page<Dashboards> getAllDashboards( ){
        Page<Dashboards> dashboards =  this.dashboardService.getAllDashboards( );
        return dashboards ;
    }

    @GetMapping("one-dashboard/{id}")
    public  Dashboards getOneDashboardById( @PathVariable("id") String id ){

        // System.out.println( id );
        Optional<Dashboards> optDashboard = this.dashboardService.getOneDashboardById( id ) ;

        if( optDashboard.isPresent() ){
            return  optDashboard.get() ;
        }
        return null ;
    }

    // Refresh connection status
    @GetMapping("setConnection/{id}")
    public void setDashboardConnection( @PathVariable("id") String id ){
        this.dashboardService.setDashboardConnection( id, true );
    }

    // Refresh connection status
    @GetMapping("removeConnection/{id}")
    public void removeConnection( @PathVariable("id") String id ){
        this.dashboardService.setDashboardConnection( id, false );
    }


    private boolean checkRequiredFields( String name ){
        if( name == null || name.isBlank() ){
            return true ;
        }
        return false ;
    }

    // Do te therritet ne rast se nuk gjendet
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(HandledException.class)
    public Exception handleNotFound(Exception exception ){
        return exception;
    }
}
