package com.example.movingDashboards.models;

import lombok.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
@Document
@PropertySource("classpath:application.properties")
public class Widgets {

    @Id
    private  String id ;

    @Indexed(unique = true )
    private String name ;

    private  String description ;

    private  String dataSource ;

    private  String chartType ;

    private  String dashboardId ;

    private  boolean deleted ;

    private  String datalabel ;

    // Do merret nga application.properties
    private double frequency ; // back-end

    private double frontFrequency ;

    // Position in grid
    private int cols ;

    private int rows ;

    private int x ;

    private int y ;


    // List per information obj
    List<InformationData> informationDataList ;

    private LocalDateTime localDateTime ;

    // Mban vleren se sa kohe me perpara do te filloje t'i beje push te dhenave.
    private long dateFilterStartingInterval ;


    public Widgets( @NonNull  String name, String description, @NonNull  String dataSource, @NonNull  String chartType,  LocalDateTime localDateTime) {
        this.name = name;
        this.description = description;
        this.dataSource = dataSource;
        this.chartType = chartType;
        this.localDateTime = localDateTime;
    }

    public Widgets( @NonNull  String name, String description, @NonNull  String dataSource, @NonNull  String chartType,
                    LocalDateTime localDateTime, String dashboardId , double frontFrequency, boolean deleted  ) {
        this.name = name;
        this.description = description;
        this.dataSource = dataSource;
        this.chartType = chartType;
        this.localDateTime = localDateTime;
        this.dashboardId = dashboardId ;
        this.frontFrequency = frontFrequency ;
        this.deleted = deleted ;
    }
    
}
