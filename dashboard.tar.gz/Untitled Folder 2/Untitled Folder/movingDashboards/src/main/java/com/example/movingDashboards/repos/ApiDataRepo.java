package com.example.movingDashboards.repos;

import com.example.movingDashboards.models.ApiData;
import com.example.movingDashboards.models.Dashboards;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApiDataRepo extends MongoRepository<ApiData, String> {

    public List<ApiData> findByNameFilter(String nameFilter );
}
