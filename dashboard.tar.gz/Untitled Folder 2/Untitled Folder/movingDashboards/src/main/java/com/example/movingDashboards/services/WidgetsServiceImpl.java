package com.example.movingDashboards.services;

import com.example.movingDashboards.dtos.WidgetData;
import com.example.movingDashboards.models.ApiData;
import com.example.movingDashboards.models.Dashboards;
import com.example.movingDashboards.models.InformationData;
import com.example.movingDashboards.models.Widgets;
import com.example.movingDashboards.repos.ApiDataRepo;
import com.example.movingDashboards.repos.DashboardsRepo;
import com.example.movingDashboards.repos.WidgetsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.Semaphore;

@EnableScheduling
@Service("widgetsService")
public class WidgetsServiceImpl implements WidgetsService {

    public WidgetsServiceImpl(){}

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    @Autowired
    private ApiDataRepo apiDataRepo ;

    @Autowired
    private Environment env;

    private WidgetsRepo widgetsRepo;
    private DashboardsRepo dashboardsRepo;

    private Semaphore semaphore = new Semaphore(1);


    @Autowired
    public WidgetsServiceImpl(WidgetsRepo widgetsRepo, DashboardsRepo dashboardsRepo) {
        this.widgetsRepo = widgetsRepo;
        this.dashboardsRepo = dashboardsRepo;
    }

    public boolean getWidgetFromName(String name) {
        Optional<Widgets> optWidget = this.widgetsRepo.findByName(name);
        return optWidget.isPresent();
    }

    public Widgets addWidget(Widgets widgets) {
        Widgets widget = this.widgetsRepo.save(widgets);
        Optional<Dashboards> optDashboard = this.dashboardsRepo.findById(widgets.getDashboardId());

        if (optDashboard.isPresent()) {
            Dashboards dashboard = optDashboard.get();
            dashboard.getWidgetIdList().add(widget.getId());
            this.dashboardsRepo.save(dashboard);
        }
        return widget;
    }

    public void saveWidgetPosition(List<Widgets> widgetWithCordinates) {
        for(Widgets wwc : widgetWithCordinates){
            if( wwc.getId() != null && !wwc.getId().isBlank()){
                Optional<Widgets> optWidgets = this.widgetsRepo.findById( wwc.getId() );
                if ( optWidgets.isPresent() ){
                    wwc.setInformationDataList( optWidgets.get().getInformationDataList() );
                }
            }
        }
        this.widgetsRepo.saveAll(widgetWithCordinates);
    }

    public void hardDelete(String id) {

        Optional<Widgets> optWidgets = this.widgetsRepo.findById(id);

        if (optWidgets.isPresent()) {
            // Widgets widgets =  optWidgets.get() ;
            Optional<Dashboards> optDashboard = this.dashboardsRepo.findById(optWidgets.get().getDashboardId());
            this.widgetsRepo.deleteById(id);

            Dashboards dashboard = optDashboard.get();
            dashboard.getWidgetIdList().remove(id);
            this.dashboardsRepo.save(dashboard);
        }
    }

    public Optional<Widgets> getOneWidget(String id) {
        return this.widgetsRepo.findById(id);
    }

    public void modifiedWidget(Widgets widget) {
        if( widget.getId() != null && !widget.getId().isBlank() ){
            Optional<Widgets> optWidget = this.widgetsRepo.findById( widget.getId() );
            widget.setInformationDataList( optWidget.get().getInformationDataList() );
            this.widgetsRepo.save(widget);
        }

    }

    public List<Widgets> getAllWidgets(String dashboardId) {
        return this.widgetsRepo.findAllNotDeleted(false, dashboardId);
    }

    //  Feed server with dummy data
    @Scheduled(fixedRateString = "${backfrequency}")
    public void feedDataWidgets() {

        int nrDevicesTemp = 50;
        int nrDevicesAir = 50;
        int nrDevicesRain = 50;
        int nrDevicesCo2 = 50;

        List<ApiData> apiDatas = new ArrayList<>();
        this.apiDataRepo.deleteAll();
        Random rand = new Random();
        int i = 0 ;

        for( ; i < nrDevicesTemp ; i++ ){
            apiDatas.add( new ApiData( 0, (double) ( rand.nextInt(40) - 80 ) , 0, 0, "temperature", rand.nextFloat(), rand.nextFloat() ) );
        }

        i = 0 ;
        for( ; i < nrDevicesAir ; i++ ){
            apiDatas.add( new ApiData( (double) ( rand.nextInt(100) ), 0 , 0, 0, "air preasure", rand.nextFloat(), rand.nextFloat() ) );
        }

        i = 0 ;
        for( ; i < nrDevicesCo2 ; i++ ){
            apiDatas.add( new ApiData( 0, 0 ,  (double) ( rand.nextInt(100) ), 0, "co2 emision", rand.nextFloat(), rand.nextFloat() ) );
        }

        i = 0 ;
        for( ; i < nrDevicesRain ; i++ ){
            apiDatas.add( new ApiData( 0, 0 , 0, (double) ( rand.nextInt(100) ), "rain percipitation", rand.nextFloat(), rand.nextFloat() ) );
        }
        this.apiDataRepo.saveAll(apiDatas );
    }





    /*
         @Scheduled(fixedDelay = 10000 ) // 5000000  // 15000
        public void sendDataToFrontEnd() throws InterruptedException {  // String dashboardId
            System.out.println( " sendDataToFrontEnd : " );
            List<Dashboards> dashboards = this.dashboardsRepo.findAll();
            List<Thread> widgetThreats = new ArrayList<>();

            for (Thread thread : widgetThreats) {
                thread.interrupt();
            }

            widgetThreats.clear();

            for( Dashboards dashboard : dashboards){
                for (String id : dashboard.getWidgetIdList()) {
                    System.out.println( " id  : " + id );

                Thread t = new Thread(this.singleWidgetData(id, dashboard.getId())) ;
                t.setName( id );

                if( !widgetThreats.contains( t ) ){
                    System.out.println( " widgetThreats if   : " + id );

                    widgetThreats.add( t );
                    t.start();
                }
                // widgetThreats.add(new Thread(this.singleWidgetData(id, dashboard.getId())));
            }
        }
    }
    */

    /*
    public Runnable singleWidgetData(String widgetId, String dashboardId) throws InterruptedException {

        return new Runnable() {

            @Override
            public void run() {
                System.out.println( " singleWidgetData : " + widgetId );
                System.out.println( " widgetId : "  );

                Optional<Dashboards> optDashboards = dashboardsRepo.findById(dashboardId);
                Optional<Widgets> optWidget = widgetsRepo.findById(widgetId);
                if (!optWidget.isPresent())
                    return;

                // while(optWidget.isPresent()) {

                    System.out.println( " while : "  );

                    Widgets widget = optWidget.get();

                    if ( widget.getChartType().equalsIgnoreCase("line") ) {
                        System.out.println( " if line : "  );

                        if( widget.getDatalabel().equalsIgnoreCase( "temperature" ) ){
                            List<InformationData> infData = transformDataTemp( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                            widget.getInformationDataList().add( infData.get(0) );
                        }else if ( widget.getDatalabel().equalsIgnoreCase( "air preasure" ) ){
                            List<InformationData> infData = transformDataAir( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                            widget.getInformationDataList().add( infData.get(0) );
                        }else if ( widget.getDatalabel().equalsIgnoreCase( "co2 emision" ) ){
                            List<InformationData> infData = transformDataCO2( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                            widget.getInformationDataList().add( infData.get(0) );
                        }else{
                            List<InformationData> infData = transformDataRain( widget.getDatalabel(), widget.getChartType(), widget.getId() );

                            if(infData.size() !=  0 ){
                                infData.get(0).setLocalDateTime( LocalDateTime.now() );
                                widget.getInformationDataList().add( infData.get(0) );
                            }
                        }

                        if( widget.getInformationDataList().size() > 30  ){
                            widget.getInformationDataList().clear();
                        }
                         widgetsRepo.save( widget );

                        // Do bejme sorting
                        Collections.sort( widget.getInformationDataList() );

                        // do te bejme filter sipas nje variabli qe do te mbahet ne DB
                        if( widget.getDateFilterStartingInterval() != 0 ){

                            List<InformationData> informationDataList = new ArrayList<>();

                            for( InformationData infoData : widget.getInformationDataList()){
                                if( infoData.getLocalDateTime().isAfter( LocalDateTime.now().minusMinutes( widget.getDateFilterStartingInterval() ) ) ){
                                    informationDataList.add( infoData );
                                }
                            }
                            widget.getInformationDataList().clear();
                            widget.setInformationDataList( informationDataList );
                        }

                        simpMessagingTemplate.convertAndSend("/topic/notification" + dashboardId,
                                widget   );  // new WidgetData(widget.getId(), widget.getInformationDataList())

                    }else {

                        System.out.println( " else : "  );
                        // bar pie
                       if( widget.getDatalabel().equalsIgnoreCase( "temperature" ) ){
                           System.out.println( " if temperature : "  );
                           List<InformationData> infData = transformDataTemp( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                           widget.setInformationDataList( infData );
                       }else if ( widget.getDatalabel().equalsIgnoreCase( "air preasure" ) ){
                           System.out.println( " if air : "  );
                           List<InformationData> infData = transformDataAir( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                           widget.setInformationDataList( infData );
                       }else if ( widget.getDatalabel().equalsIgnoreCase( "co2 emision" ) ){
                           System.out.println( " if co2 : "  );
                           List<InformationData> infData = transformDataCO2( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                           widget.setInformationDataList( infData );
                       }else{
                           System.out.println( " else rain : "  );
                           List<InformationData> infData = transformDataRain( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                           widget.setInformationDataList( infData );
                       }

                        System.out.println( " pushing : "  );
                        simpMessagingTemplate.convertAndSend("/topic/notification" + dashboardId,
                                widget   );  // new WidgetData(widget.getId(), widget.getInformationDataList())

                        System.out.println( " after pushing : "  );
                    }

                    try {
                        System.out.println( " thread sleap : "  );
                        Thread.sleep((long) (Math.round(widget.getFrontFrequency())));
                        System.out.println( " after thread sleap : "  );
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }


                     if (!optDashboards.isPresent()) {
                         return;
                     }

                     if (!optDashboards.get().getWidgetIdList().contains(widgetId)) {
                         return;
                     }

                   // if (!optDashboards.get().isConnectionCheck()) {
                    //    return;
                   // }

                    optWidget = widgetsRepo.findById(widgetId);
                    System.out.println( " end while : "  );

                // }
                return;
            }
        };
    }
    */


    public void singleWidgetData(String widgetId, String dashboardId) {

        // return new Runnable() {

            //@Override
           // public void run() {
                System.out.println( " singleWidgetData : " + widgetId );
                System.out.println( " widgetId : "  );

                Optional<Dashboards> optDashboards = dashboardsRepo.findById(dashboardId);
                Optional<Widgets> optWidget = widgetsRepo.findById(widgetId);
                if (!optWidget.isPresent())
                    return;

                while(optWidget.isPresent()) {

                System.out.println( " while : "  );

                Widgets widget = optWidget.get();

                if ( widget.getChartType().equalsIgnoreCase("line") ) {
                    System.out.println( " if line : "  );

                    if( widget.getDatalabel().equalsIgnoreCase( "temperature" ) ){
                        List<InformationData> infData = transformDataTemp( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                        widget.getInformationDataList().add( infData.get(0) );
                    }else if ( widget.getDatalabel().equalsIgnoreCase( "air preasure" ) ){
                        List<InformationData> infData = transformDataAir( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                        widget.getInformationDataList().add( infData.get(0) );
                    }else if ( widget.getDatalabel().equalsIgnoreCase( "co2 emision" ) ){
                        List<InformationData> infData = transformDataCO2( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                        widget.getInformationDataList().add( infData.get(0) );
                    }else{
                        List<InformationData> infData = transformDataRain( widget.getDatalabel(), widget.getChartType(), widget.getId() );

                        if(infData.size() !=  0 ){
                            infData.get(0).setLocalDateTime( LocalDateTime.now() );
                            widget.getInformationDataList().add( infData.get(0) );
                        }
                    }

                    if( widget.getInformationDataList().size() > 30  ){
                        widget.getInformationDataList().clear();
                    }
                    widgetsRepo.save( widget );

                    // Do bejme sorting
                    Collections.sort( widget.getInformationDataList() );

                    // do te bejme filter sipas nje variabli qe do te mbahet ne DB
                    if( widget.getDateFilterStartingInterval() != 0 ){

                        List<InformationData> informationDataList = new ArrayList<>();

                        for( InformationData infoData : widget.getInformationDataList()){
                            if( infoData.getLocalDateTime().isAfter( LocalDateTime.now().minusMinutes( widget.getDateFilterStartingInterval() ) ) ){
                                informationDataList.add( infoData );
                            }
                        }
                        widget.getInformationDataList().clear();
                        widget.setInformationDataList( informationDataList );
                    }

                    simpMessagingTemplate.convertAndSend("/topic/notification" + dashboardId,
                            widget   );  // new WidgetData(widget.getId(), widget.getInformationDataList())

                }else {

                    System.out.println( " else : "  );
                    // bar pie
                    if( widget.getDatalabel().equalsIgnoreCase( "temperature" ) ){
                        System.out.println( " if temperature : "  );
                        List<InformationData> infData = transformDataTemp( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                        widget.setInformationDataList( infData );
                    }else if ( widget.getDatalabel().equalsIgnoreCase( "air preasure" ) ){
                        System.out.println( " if air : "  );
                        List<InformationData> infData = transformDataAir( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                        widget.setInformationDataList( infData );
                    }else if ( widget.getDatalabel().equalsIgnoreCase( "co2 emision" ) ){
                        System.out.println( " if co2 : "  );
                        List<InformationData> infData = transformDataCO2( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                        widget.setInformationDataList( infData );
                    }else{
                        System.out.println( " else rain : "  );
                        List<InformationData> infData = transformDataRain( widget.getDatalabel(), widget.getChartType(), widget.getId() );
                        widget.setInformationDataList( infData );
                    }

                    System.out.println( " pushing : "  );
                    simpMessagingTemplate.convertAndSend("/topic/notification" + dashboardId,
                            widget   );  // new WidgetData(widget.getId(), widget.getInformationDataList())

                    System.out.println( " after pushing : "  );
                }

                try {
                    System.out.println( " thread sleap : "  );
                    Thread.sleep((long) (Math.round(widget.getFrontFrequency())));
                    System.out.println( " after thread sleap : "  );
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (!optDashboards.isPresent()) {
                    return;
                }

                if (!optDashboards.get().getWidgetIdList().contains(widgetId)) {
                    return;
                }

                // if (!optDashboards.get().isConnectionCheck()) {
                //    return;
                // }

                optWidget = widgetsRepo.findById(widgetId);
                System.out.println( " end while : "  );

                }
                // return;
           // }
        // };
    }

    public void changeDateFilterStartingInterval(String id, long value) {
        Optional<Dashboards> optDashboard = this.dashboardsRepo.findById(id);

        if (optDashboard.isPresent()) {
            Dashboards dashboard = optDashboard.get();

            for(String wid : dashboard.getWidgetIdList()){
                Optional<Widgets> optWidgets = this.widgetsRepo.findById(wid);

                if( optWidgets.isPresent() ){
                    Widgets widget = optWidgets.get();
                    widget.setDateFilterStartingInterval( value );
                    this.widgetsRepo.save( widget );
                }
            }
        }
    }

    private List<InformationData> transformDataTemp( String filter, String chartType, String wid ){

        int nrDevices = 50 ;
        List<InformationData> informationDataList = new ArrayList<>();
        List<ApiData> apiDatas = apiDataRepo.findByNameFilter( filter );

            if ( chartType.equalsIgnoreCase("line")) {
                double s = 0 ;

                for( ApiData ad : apiDatas){
                    s = s + ad.getTemp() ;
                }

                Random rand = new Random();
                int dumyTime = rand.nextInt( 50) + 1 ;
                informationDataList.add( new InformationData(LocalDateTime.now().minusMinutes( (long ) dumyTime) + "", LocalDateTime.now(), ( s / apiDatas.size() )  , "line" )) ;

            }else if ( chartType.equalsIgnoreCase("pie")) {

                // Grupimi  pie

                Map<Double, Integer >  apiDataGrouped = new HashMap<>();

                for( ApiData ad : apiDatas ){
                    if( !apiDataGrouped.containsKey( ad.getTemp() ) ){
                        apiDataGrouped.put( ad.getTemp(), 1  );
                    }else{
                        int val = apiDataGrouped.get( ad.getTemp() ) + 1 ;
                        apiDataGrouped.put( ad.getTemp(), val );
                    }
                }

                int i = 0 ;
                for( double mapKey : apiDataGrouped.keySet() ){
                    informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), ( 100 * apiDataGrouped.get( mapKey ) / nrDevices ), "pie")) ;
                    i++;
                }

            }else{
                // Grupimi  Bar

                Map<Double, Integer >  apiDataGrouped = new HashMap<>();

                for( ApiData ad : apiDatas ){
                    if( !apiDataGrouped.containsKey( ad.getTemp() ) ){
                        apiDataGrouped.put( ad.getTemp(), 1  );
                    }else{
                        int val = apiDataGrouped.get( ad.getTemp() ) + 1 ;
                        apiDataGrouped.put( ad.getTemp(), val );
                    }
                }

                int i = 0 ;
                for( double mapKey : apiDataGrouped.keySet() ){
                    informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), apiDataGrouped.get( mapKey )  , "bar")) ;
                    i++;
                }
        }
        return informationDataList ;
    }



    private List<InformationData> transformDataAir( String filter, String chartType, String wid ){

        int nrDevices = 50 ;
        List<InformationData> informationDataList = new ArrayList<>();
        List<ApiData> apiDatas = apiDataRepo.findByNameFilter( filter );

        if ( chartType.equalsIgnoreCase("line")) {

            double s = 0 ;

            for( ApiData ad : apiDatas){
                s = s + ad.getAir() ;
            }

            Random rand = new Random();
            int dumyTime = rand.nextInt( 50) + 1 ;
            informationDataList.add( new InformationData(LocalDateTime.now().minusMinutes( (long ) dumyTime) + "", LocalDateTime.now(), ( s / apiDatas.size() )  , "line" )) ;

        }else if ( chartType.equalsIgnoreCase("pie")) {

            // Grupimi  pie

            Map<Double, Integer >  apiDataGrouped = new HashMap<>();

            for( ApiData ad : apiDatas ){
                if( !apiDataGrouped.containsKey( ad.getAir() ) ){
                    apiDataGrouped.put( ad.getAir(), 1  );
                }else{
                    int val = apiDataGrouped.get( ad.getAir() ) + 1 ;
                    apiDataGrouped.put( ad.getAir(), val );
                }
            }

            int i = 0 ;
            for( double mapKey : apiDataGrouped.keySet() ){
                informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), ( 100 * apiDataGrouped.get( mapKey ) / nrDevices ), "pie")) ;
                i++;
            }

        }else{
            // Grupimi  Bar

            Map<Double, Integer >  apiDataGrouped = new HashMap<>();

            for( ApiData ad : apiDatas ){
                if( !apiDataGrouped.containsKey( ad.getAir() ) ){
                    apiDataGrouped.put( ad.getAir(), 1  );
                }else{
                    int val = apiDataGrouped.get( ad.getAir() ) + 1 ;
                    apiDataGrouped.put( ad.getAir(), val );
                }
            }

            int i = 0 ;
            for( double mapKey : apiDataGrouped.keySet() ){
                informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), apiDataGrouped.get( mapKey )  , "bar")) ;
                i++;
            }
        }
        return informationDataList ;
    }



    private List<InformationData> transformDataRain( String filter, String chartType, String wid ){

        int nrDevices = 50 ;
        List<InformationData> informationDataList = new ArrayList<>();
        List<ApiData> apiDatas = apiDataRepo.findByNameFilter( filter );

        if ( chartType.equalsIgnoreCase("line")) {

            double s = 0 ;
            for( ApiData ad : apiDatas){
                s = s + ad.getRain() ;
            }

            Random rand = new Random();
            int dumyTime = rand.nextInt( 50) + 1 ;
            informationDataList.add( new InformationData(LocalDateTime.now().minusMinutes( (long ) dumyTime) + "", LocalDateTime.now(), ( s / apiDatas.size() )  , "line" )) ;

        }else if ( chartType.equalsIgnoreCase("pie")) {

            // Grupimi  pie

            Map<Double, Integer >  apiDataGrouped = new HashMap<>();

            for( ApiData ad : apiDatas ){
                if( !apiDataGrouped.containsKey( ad.getRain() ) ){
                    apiDataGrouped.put( ad.getRain(), 1  );
                }else{
                    int val = apiDataGrouped.get( ad.getRain() ) + 1 ;
                    apiDataGrouped.put( ad.getRain(), val );
                }
            }

            int i = 0 ;
            for( double mapKey : apiDataGrouped.keySet() ){
                informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), ( 100 * apiDataGrouped.get( mapKey ) / nrDevices ), "pie")) ;
                i++;
            }

        }else{
            // Grupimi  Bar

            Map<Double, Integer >  apiDataGrouped = new HashMap<>();

            for( ApiData ad : apiDatas ){
                if( !apiDataGrouped.containsKey( ad.getRain() ) ){
                    apiDataGrouped.put( ad.getRain(), 1  );
                }else{
                    int val = apiDataGrouped.get( ad.getRain() ) + 1 ;
                    apiDataGrouped.put( ad.getRain(), val );
                }
            }

            int i = 0 ;
            for( double mapKey : apiDataGrouped.keySet() ){
                informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), apiDataGrouped.get( mapKey )  , "bar")) ;
                i++;
            }
        }
        return informationDataList ;
    }

    private List<InformationData> transformDataCO2( String filter, String chartType, String wid ){

        int nrDevices = 50 ;
        List<InformationData> informationDataList = new ArrayList<>();
        List<ApiData> apiDatas = apiDataRepo.findByNameFilter( filter );

        if ( chartType.equalsIgnoreCase("line")) {
            double s = 0 ;

            for( ApiData ad : apiDatas){
                s = s + ad.getCo2() ;
            }

            Random rand = new Random();
            int dumyTime = rand.nextInt( 50) + 1 ;
            informationDataList.add( new InformationData(LocalDateTime.now().minusMinutes( (long ) dumyTime) + "", LocalDateTime.now(), ( s / apiDatas.size() )  , "line" )) ;

        }else if ( chartType.equalsIgnoreCase("pie")) {

            // Grupimi  pie

            Map<Double, Integer >  apiDataGrouped = new HashMap<>();

            for( ApiData ad : apiDatas ){
                if( !apiDataGrouped.containsKey( ad.getCo2() ) ){
                    apiDataGrouped.put( ad.getCo2(), 1  );
                }else{
                    int val = apiDataGrouped.get( ad.getCo2() ) + 1 ;
                    apiDataGrouped.put( ad.getCo2(), val );
                }
            }

            int i = 0 ;
            for( double mapKey : apiDataGrouped.keySet() ){
                informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), ( 100 * apiDataGrouped.get( mapKey ) / nrDevices ), "pie")) ;
                i++;
            }

        }else{
            // Grupimi  Bar

            Map<Double, Integer >  apiDataGrouped = new HashMap<>();

            for( ApiData ad : apiDatas ){
                if( !apiDataGrouped.containsKey( ad.getCo2() ) ){
                    apiDataGrouped.put( ad.getCo2(), 1  );
                }else{
                    int val = apiDataGrouped.get( ad.getCo2() ) + 1 ;
                    apiDataGrouped.put( ad.getCo2(), val );
                }
            }

            int i = 0 ;
            for( double mapKey : apiDataGrouped.keySet() ){
                informationDataList.add( new InformationData(mapKey + "", LocalDateTime.now().minusMinutes((long) i), apiDataGrouped.get( mapKey )  , "bar")) ;
                i++;
            }
        }
        return informationDataList ;
    }

    public Optional<Widgets> nameWidgetExistence(String name, String id ){
        return this.widgetsRepo.nameMatch( name, id );
    }

}
