package com.example.movingDashboards.models;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
public class InformationData implements Comparable<InformationData> {

    // Ska mbaruar

    private String name ;

    // Mbase duhet Date
    private LocalDateTime localDateTime ;

    private  double value ;

    private String dataType ;

    public InformationData(String name, LocalDateTime localDateTime, double value, String dataType ) {
        this.name = name;
        this.localDateTime = localDateTime;
        this.value = value;
        this.dataType = dataType ;
    }

    @Override
    public int compareTo(InformationData informationData) {
        return this.localDateTime.compareTo( informationData.localDateTime );
    }
}
