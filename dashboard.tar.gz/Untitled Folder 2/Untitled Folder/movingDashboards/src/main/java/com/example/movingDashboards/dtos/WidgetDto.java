package com.example.movingDashboards.dtos;

import com.example.movingDashboards.models.InformationData;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
public class WidgetDto {

    private  String id ;
    private String charttype ;
    private String dashboardId;
    private String dataSource;
    private String description;
    private double frontFrequency ;
    private String name;
    private String datalabel ;

    // Position in grid
    private int cols ;

    private int rows ;

    private int x ;

    private int y ;

    // e shhtuar
    List<InformationData> informationDataList ;

    public WidgetDto(String id, String charttype, String description, double frontFrequency, String name,
                     String dashboardId, String dataSource,
                     int cols, int rows, int x, int y, List<InformationData> informationDataList  ) { //
        this.charttype = charttype;
         this.dashboardId = dashboardId;
        this.dataSource = dataSource;
        this.description = description;
        this.frontFrequency = frontFrequency;
        this.name = name;
        this.id = id ;
        this.cols = cols ;
        this.rows = rows ;
        this.x = x ;
        this.y = y ;
        this.informationDataList = informationDataList ;
    }

    public WidgetDto(String id, String charttype, String description, double frontFrequency, String name,
                     String dashboardId, String dataSource,
                     int cols, int rows, int x, int y ) { //
        this.charttype = charttype;
        this.dashboardId = dashboardId;
        this.dataSource = dataSource;
        this.description = description;
        this.frontFrequency = frontFrequency;
        this.name = name;
        this.id = id ;
        this.cols = cols ;
        this.rows = rows ;
        this.x = x ;
        this.y = y ;
    }
}
