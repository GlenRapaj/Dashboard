package com.example.movingDashboards.services;


import com.example.movingDashboards.models.Dashboards;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Optional;

public interface DashboardService {

   // public void seeFreqValue();
   public String saveDashboards(Dashboards dashboards );
   public Page<Dashboards> getAllDashboards(int page, int size ) ;
   public  boolean deleteDashboard( String id );
   public  void rvertDelete( String id );
   public Optional<Dashboards> getOneDashboardById(String id );
   public Dashboards getOneDashboard( String id );
   public boolean modyfieDashboard( Dashboards dashboards );
   public  Page<Dashboards> filterDashboards( String name, int page, int size );
   public List<Dashboards> listDeletedDashboards();
   public Dashboards getOneDashboardByName( String name );
   public boolean setDashboardOpened( String id );
   public boolean  hardDelete( String id );
   public Page<Dashboards> getAllDashboards( );

   public void setDashboardConnection( String dashboardId, Boolean newConnectionStatus );
}
