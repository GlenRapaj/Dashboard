package com.example.movingDashboards.controllers;

import com.example.movingDashboards.config.HandledException;
import com.example.movingDashboards.dtos.WidgetDto;
import com.example.movingDashboards.models.Dashboards;
import com.example.movingDashboards.models.Widgets;
import com.example.movingDashboards.services.DashboardService;
import com.example.movingDashboards.services.WidgetsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/widgets/")
@CrossOrigin("*")
public class WidgetsController {

    @Autowired
    private Environment env;

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate ;

    private WidgetsService widgetsService ;
    private DashboardService dashboardService ;

    public WidgetsController( @Qualifier("widgetsService") WidgetsService widgetsService, @Qualifier("dashboardService") DashboardService dashboardService  ){
        this.widgetsService = widgetsService ;
        this.dashboardService = dashboardService ;
    }


    @ResponseStatus(HttpStatus.OK)
    @PostMapping("add-widget")
    public void addWidget( @RequestBody WidgetDto widgetDto ){

        if( this.checkRequiredFields( widgetDto.getName() ) ){
            throw new HandledException("Widget name can not bee blank.") ;
        }

        if( this.checkRequiredFields( widgetDto.getDataSource() ) ){
            throw new HandledException(" Data Source can not bee blank.") ;
        }

        if( this.checkRequiredFields( widgetDto.getCharttype() ) ){
            throw new HandledException("Chart Type can not bee blank.") ;
        }

        if( (Double) widgetDto.getFrontFrequency() == null ){
            throw new HandledException(" Frequency can not bee blank.") ;
        }

        /*
        if(  widgetDto.getFrontFrequency() < ( Double.parseDouble( env.getProperty("widget.frequency") ) * 0.001 ) || widgetDto.getFrontFrequency() > ( Double.parseDouble( env.getProperty("widget.frequency") ) * 6 * 0.001  )   ){
           String a = env.getProperty("widget.frequency") ;

            widgetDto.setFrontFrequency( ( Double.parseDouble( a ) ) );
          throw new HandledException(" Frequency must be between " + a + "  and " + ( Double.parseDouble( a ) * 6 )  + " Default value is "  + a + " \n Default is selectec." ) ;
        }else{
            widgetDto.setFrontFrequency(( widgetDto.getFrontFrequency() * 1000 )  );
        }

         */

        if( !widgetDto.getCharttype().equalsIgnoreCase("pie") &&
                !widgetDto.getCharttype().equalsIgnoreCase("bar") &&
                !widgetDto.getCharttype().equalsIgnoreCase("line")   ){
            throw new HandledException("Chart Type undefined.") ;
        }

        if( this.checkRequiredFields( widgetDto.getDatalabel() ) ){
            throw new HandledException("Data Label can not bee blank.") ;
        }

        boolean widgetexist = this.widgetsService.getWidgetFromName( widgetDto.getName() );

        if( widgetexist ){
            throw new HandledException(" Widget exist. Choose another name.") ;
        }

        Widgets widgets = new Widgets( widgetDto.getName(), widgetDto.getDescription(), widgetDto.getDataSource(), widgetDto.getCharttype(),
                LocalDateTime.now(), widgetDto.getDashboardId() , widgetDto.getFrontFrequency(), false );
        widgets.setFrequency( Double.parseDouble( env.getProperty("widget.frequency") ) );
        widgets.setDatalabel( widgetDto.getDatalabel() );
        widgets.setInformationDataList( new ArrayList<>());

        this.widgetsService.addWidget( widgets );
    }


    @ResponseStatus(HttpStatus.OK)
    @GetMapping("all-widgets/{id}")
    public List<WidgetDto> getAllWidgets( @PathVariable("id") String dashboardId ){
        List<Widgets> widgets = this.widgetsService.getAllWidgets( dashboardId );
        List<WidgetDto>  widgetDto = new ArrayList<>();

        for(Widgets widget : widgets){
            int col = 1 ;
            int row = 1 ;

            if( widget.getCols() != 0 ){
                col = widget.getCols() ;
            }

            if( widget.getRows() != 0 ){
                row = widget.getRows();
            }
            WidgetDto widgetDto1 = new WidgetDto( widget.getId(), widget.getChartType(), widget.getDescription(), ( widget.getFrontFrequency() * 0.001 ), widget.getName(),
                    widget.getDashboardId(), widget.getDataSource(), col, row, widget.getX(), widget.getY(), widget.getInformationDataList() );
            widgetDto1.setDatalabel( widget.getDatalabel() );
            widgetDto.add( widgetDto1 );
        }
        return  widgetDto ;
    }

    @PutMapping("save-configuration")
    @ResponseStatus(HttpStatus.OK)
    public void saveWidgetPosition( @RequestBody List<WidgetDto> widgetWithCordinates ){

        for( WidgetDto wdc : widgetWithCordinates){
            if( this.checkRequiredFields( wdc.getName() ) ){
                throw new HandledException("Widget name can not bee blank.") ;
            }

            /* */
            if( this.checkRequiredFields( wdc.getDataSource() ) ){
                throw new HandledException(" Data Source can not bee blank.") ;
            }

            if( this.checkRequiredFields( wdc.getCharttype() ) ){
                throw new HandledException("Chart Type can not bee blank.") ;
            }

            if( (Double) wdc.getFrontFrequency() == null ){
                throw new HandledException(" Frequency can not bee blank.") ;
            }

            if(  wdc.getFrontFrequency() < ( Double.parseDouble( env.getProperty("widget.frequency") ) * 0.001 ) || wdc.getFrontFrequency() > ( Double.parseDouble( env.getProperty("widget.frequency") ) * 6 * 0.001  )   ){
                String a = env.getProperty("widget.frequency") ;

                wdc.setFrontFrequency( ( Double.parseDouble( a ) ) );
                throw new HandledException(" Frequency must be between " + a + "  and " + ( Double.parseDouble( a ) * 6 )  + " Default value is "  + a + " \n Default is selectec." ) ;
            }else{
                wdc.setFrontFrequency(( wdc.getFrontFrequency() * 1000 )  );
            }

            if( !wdc.getCharttype().equalsIgnoreCase("pie") &&
                    !wdc.getCharttype().equalsIgnoreCase("bar") &&
                    !wdc.getCharttype().equalsIgnoreCase("line")   ){
                throw new HandledException("Chart Type undefined.") ;
            }

            if( this.checkRequiredFields( wdc.getDatalabel() ) ){
                throw new HandledException("Data Label can not bee blank.") ;
            }

            boolean widgetexist = this.widgetsService.getWidgetFromName( wdc.getName() );

            if( !widgetexist ){
                throw new HandledException(" Widget dont exist.") ;
            }
        }

        List<Widgets> widgets = new ArrayList<>();
        boolean elementInFirstRow = false ;

        for(WidgetDto widgetCordinates : widgetWithCordinates){
            if( widgetCordinates.getY() == 0 ){
                elementInFirstRow = true ;
                break;
            }
        }
/*
        if( elementInFirstRow ){
            for(WidgetDto widgetCordinates : widgetWithCordinates){
                widgetCordinates.setY( widgetCordinates.getY() + 10 );
            }
        }
*/
        for(WidgetDto widgetCordinates : widgetWithCordinates){
            Widgets widget = new Widgets( widgetCordinates.getName(), widgetCordinates.getDescription(), widgetCordinates.getDataSource(), widgetCordinates.getCharttype(),
                    LocalDateTime.now(), widgetCordinates.getDashboardId() , widgetCordinates.getFrontFrequency(), false );

            widget.setCols( widgetCordinates.getCols() );
            widget.setRows( widgetCordinates.getRows() );
            widget.setX( widgetCordinates.getX() );
            widget.setY( widgetCordinates.getY() );
            widget.setId( widgetCordinates.getId() );
            widget.setDatalabel( widgetCordinates.getDatalabel() );
            widget.setInformationDataList( new ArrayList<>());
            widgets.add( widget );
        }
        this.widgetsService.saveWidgetPosition( widgets );
    }

    @DeleteMapping("hard-delete-widget/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void hardDelete( @PathVariable String id ){
        this.widgetsService.hardDelete( id );
    }

    @GetMapping("get-one-widget/{id}")
    @ResponseStatus(HttpStatus.OK)
    public WidgetDto getOneWidget(@PathVariable("id") String id ){
        Optional<Widgets> optWidget = this.widgetsService.getOneWidget( id );

        if( optWidget.isPresent() ){
            WidgetDto widgetDto = new WidgetDto( optWidget.get().getId(), optWidget.get().getChartType() , optWidget.get().getDescription() , ( optWidget.get().getFrontFrequency() * 0.001 ),
                    optWidget.get().getName(), optWidget.get().getDashboardId(),  optWidget.get().getDataSource(),
                    optWidget.get().getCols(), optWidget.get().getRows(), optWidget.get().getX(), optWidget.get().getY() );
            widgetDto.setDatalabel( optWidget.get().getDatalabel() );

            return widgetDto ;
        }
        return null ;
    }

    @ResponseStatus(HttpStatus.OK)
    @PutMapping("modified-widget")
    public void modifiedWidget(@RequestBody WidgetDto widgetCordinates ){

        if( this.checkRequiredFields( widgetCordinates.getName() ) ){
            throw new HandledException("Widget name can not bee blank.") ;
        }

        if( this.checkRequiredFields( widgetCordinates.getDataSource() ) ){
            throw new HandledException(" Data Source can not bee blank.") ;
        }

        if( this.checkRequiredFields( widgetCordinates.getCharttype() ) ){
            throw new HandledException("Chart Type can not bee blank.") ;
        }

        if( (Double) widgetCordinates.getFrontFrequency() == null ){
            throw new HandledException(" Frequency can not bee blank.") ;
        }

        if(  widgetCordinates.getFrontFrequency() < ( Double.parseDouble( env.getProperty("widget.frequency") ) * 0.001 ) || widgetCordinates.getFrontFrequency() > ( Double.parseDouble( env.getProperty("widget.frequency") ) * 6 * 0.001  )   ){
            String a = env.getProperty("widget.frequency") ;

            widgetCordinates.setFrontFrequency( ( Double.parseDouble( a ) ) );
            throw new HandledException(" Frequency must be between " + a + "  and " + ( Double.parseDouble( a ) * 6 )  + " Default value is "  + a + " \n Default is selectec." ) ;
        }else{
            widgetCordinates.setFrontFrequency(( widgetCordinates.getFrontFrequency() * 1000 )  );
        }

        if( !widgetCordinates.getCharttype().equalsIgnoreCase("pie") &&
                !widgetCordinates.getCharttype().equalsIgnoreCase("bar") &&
                !widgetCordinates.getCharttype().equalsIgnoreCase("line")   ){
            throw new HandledException("Chart Type undefined.") ;
        }

        if( this.checkRequiredFields( widgetCordinates.getDatalabel() ) ){
            throw new HandledException("Data Label can not bee blank.") ;
        }

        boolean widgetexist = this.widgetsService.getWidgetFromName( widgetCordinates.getName() );

        if( !widgetexist ){
            throw new HandledException(" Widget name dont exist.") ;
        }

        Optional<Widgets> optWidgets = this.widgetsService.nameWidgetExistence( widgetCordinates.getName(), widgetCordinates.getId() );
        if( optWidgets.isPresent() ){
            throw new HandledException(" Widget name alredy exist.") ;
        }

        Widgets widget = new Widgets( widgetCordinates.getName(), widgetCordinates.getDescription(), widgetCordinates.getDataSource(), widgetCordinates.getCharttype(),
                LocalDateTime.now(), widgetCordinates.getDashboardId() , widgetCordinates.getFrontFrequency() , false );

        widget.setCols( widgetCordinates.getCols() );
        widget.setRows( widgetCordinates.getRows() );
        widget.setX( widgetCordinates.getX() );
        widget.setY( widgetCordinates.getY() );
        widget.setId( widgetCordinates.getId() );
        widget.setDatalabel( widgetCordinates.getDatalabel() );

        this.widgetsService.modifiedWidget( widget );
    }

    /*    */
    @ResponseStatus(HttpStatus.OK)
    @GetMapping("dashboard-push-data")  // /{id}
    public void dashboardPushData() throws InterruptedException {  // @PathVariable("id") String id
       // this.widgetsService.sendDataToFrontEnd(   );
    }

    @PostMapping("activate-widget/{id}")
    public  void activateWidget( @PathVariable("id") String id , @RequestBody String dashboardId ){ //

        this.dashboardService.setDashboardConnection( dashboardId, false );
        Optional<Widgets> optWidget = this.widgetsService.getOneWidget( id );

       if( optWidget.isPresent() ){
           try {
               Thread.sleep((long) optWidget.get().getFrontFrequency());
           } catch (InterruptedException e) {
               e.printStackTrace();
           }
       }

        this.dashboardService.setDashboardConnection( dashboardId, true );
        this.widgetsService.singleWidgetData(id, dashboardId );
    }


    @ResponseStatus(HttpStatus.OK)
    @GetMapping("date-filter-value/{id}/{value}")
    public void changeDateFilterStartingInterval(  @PathVariable("id") String id , @PathVariable("value") String value  ){
        this.widgetsService.changeDateFilterStartingInterval( id, Long.parseLong( value ) );
    }

    private boolean checkRequiredFields( String name ){
        if( name == null || name.isBlank() ){
            return true ;
        }
        return false ;
    }

    // Do te therritet ne rast se nuk gjendet
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(HandledException.class)
    public Exception handleNotFound(Exception exception ){
        return exception;
    }
}
