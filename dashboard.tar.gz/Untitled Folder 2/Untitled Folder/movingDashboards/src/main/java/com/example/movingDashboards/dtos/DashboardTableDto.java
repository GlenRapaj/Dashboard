package com.example.movingDashboards.dtos;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@EqualsAndHashCode
public class DashboardTableDto {

    private String id ;
    private String name ;

    private  String description ;

    public DashboardTableDto(String id ,String name, String description) {
        this.name = name;
        this.description = description;
        this.id = id ;
    }
}
