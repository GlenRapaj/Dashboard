package com.example.movingDashboards;

import com.example.movingDashboards.services.WidgetsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class MovingDashboardsApplication {

	public static void main(String[] args) {

		ApplicationContext ctx =  SpringApplication.run(MovingDashboardsApplication.class, args);

		/*
		WidgetsServiceImpl m = (WidgetsServiceImpl) ctx.getBean("widgetsService") ;
		try {
			m.sendDataToFrontEnd();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

*/

	}

}
