package com.example.movingDashboards.repos;

import com.example.movingDashboards.models.Dashboards;
import com.example.movingDashboards.models.Widgets;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;
import java.util.Optional;

public interface WidgetsRepo  extends MongoRepository<Widgets, String> {

    public Optional<Widgets> findByName(String name);

    // @Query( value = " { $or: [ {'deleted' :?0} ]} ")
    @Query( value = " { $and: [  {'deleted' :?0},  {'dashboardId' : ?1}  ] } " )
    List<Widgets> findAllNotDeleted(boolean deleted, String dashboardId  );

    @Query( value = " {  $and: [  {'name' : ?0 },   { id: { $ne: ?1 } }  ] }  ")
    Optional<Widgets> nameMatch(String name, String id );
}
