import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';
import { GridsterModule } from 'angular-gridster2';

// my components
import { ErrorComponent } from './dumy/error/error.component';
import { HomeComponent } from './main_components/home/home.component';
import { DashboardDataComponent } from './main_components/dashboard-data/dashboard-data.component';

// Angular Material
import {DragDropModule} from '@angular/cdk/drag-drop';
import { DashboardComponent } from './main_components/dashboard/dashboard.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {MatTableModule} from '@angular/material/table';
import {MatDialogModule} from '@angular/material/dialog';
import { DeleteDialogeComponent } from './dumy/delete-dialoge/delete-dialoge.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import { ErrorpopupComponent } from './dumy/errorpopup/errorpopup.component';
import {MatCardModule} from '@angular/material/card';
import {MatMenuModule} from '@angular/material/menu';
import { ExistingDashboardComponent } from './dumy/existing-dashboard/existing-dashboard.component';
import { FlexLayoutModule, FlexModule, GridModule } from '@angular/flex-layout';
import { WidgetComponent } from './dumy/widget/widget.component';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatToolbarModule} from '@angular/material/toolbar';
import { EditWidgetComponent } from './dumy/edit-widget/edit-widget.component';
import { ChartsModule } from 'ng2-charts';
import { MatButton, MatButtonModule } from '@angular/material/button';
import { WorldmapComponent } from './dumy/worldmap/worldmap.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatTooltipModule} from '@angular/material/tooltip';


@NgModule({
  declarations: [
    HomeComponent,
    DashboardDataComponent,
    DashboardComponent,
    ErrorComponent,
    DeleteDialogeComponent,
    ErrorpopupComponent,
    ExistingDashboardComponent,
    WidgetComponent,
    EditWidgetComponent,
    WorldmapComponent
  ],

  imports: [
    CommonModule,
    CoreRoutingModule,
    HttpClientModule,
    FlexLayoutModule,
    GridsterModule,
    ChartsModule,
    GridModule,
    FlexModule,

    // angular
    DragDropModule,
    MatSidenavModule,
    MatIconModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatTableModule,
    MatDialogModule,
    MatPaginatorModule,
    MatCardModule,
    MatMenuModule,
    MatInputModule,
    MatSelectModule,
    MatToolbarModule,
    MatButtonModule,
    MatSnackBarModule,
    MatTooltipModule
  ],

  /* 
  exports: [
    MatFormFieldModule,
    MatInputModule 
  ],
 */
  entryComponents: [
    WidgetComponent,
    DeleteDialogeComponent,
    ErrorpopupComponent,
    EditWidgetComponent,
    ErrorComponent
  ],
})
export class CoreModule { }
