import { Component, OnInit } from '@angular/core';
import { DashboardTableDto } from '../../interfaces/dashboardTableDto.interface';
import { DashboardServicesService } from '../../services/dashboard-services.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  datashow : boolean = false ;
  dataArr : DashboardTableDto[] = [] ;

  statusColor : string = 'green' ;
  connectionText : string = 'connected';  // Duhet updetuar tek funksionet ku kontrollohet statusi
  
  constructor( private dashboardService: DashboardServicesService ) { }

  ngOnInit(): void {
    this.getOrReload();
  }

  getOrReload() {

    this.statusColor = 'green';
    this.connectionText = 'connected';

    this.dashboardService.lastOpenedDashboards( ) 
      .subscribe(res => {

        const arr = [];
        if( res.content.length > 0 ){
          this.datashow = true ;
        }

        let i = 0 ;

        while( i < res.content.length && i < 3 ){
          this.dataArr.push( {
            id : res.content[i].id ,
            name: res.content[i].name,
            description: res.content[i].description,
          } ); 

          i++ ;
        }

      }, error =>{ 
        this.statusColor = 'red';
        this.connectionText = 'disconnected';
      });
  }

}
