import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { DeleteDialogeComponent } from '../../dumy/delete-dialoge/delete-dialoge.component';
import { ErrorComponent } from '../../dumy/error/error.component';
import { ExistingDashboardComponent } from '../../dumy/existing-dashboard/existing-dashboard.component';
import { DashboardPostDto } from '../../interfaces/dashboardPostDto.interface';
import { DashboardTableDto } from '../../interfaces/dashboardTableDto.interface';
import { DashboardServicesService } from '../../services/dashboard-services.service';
import { Subscribable, Subscription, timer } from 'rxjs';
import { ErrorStateMatcher, ThemePalette } from '@angular/material/core';
import { MatSnackBar } from '@angular/material/snack-bar';

// E shtuar
const source = timer(1000, 1000);

@Component({
  selector: 'app-dashboard-data',
  templateUrl: './dashboard-data.component.html',
  styleUrls: ['./dashboard-data.component.scss']
})
export class DashboardDataComponent implements OnInit, OnDestroy, AfterViewInit {

  form !: FormGroup;
  filtercontainer !: FormGroup;

  displayedColumns: string[] = ['name', 'description', 'view', 'edit', 'delete'];
  dataSource !: MatTableDataSource<DashboardTableDto>;
  id: string = '';

  statusColor : string = 'green' ;
  connectionText : string = 'connected';

  matcher = new ErrorStateMatcher();

  show: string = 'none';
  edit: string = 'none';
  add: string = 'block';

  errmsg: boolean = false;
  errorMesage: string = '';

  filtered: boolean = false;

  deleteDashboards : DashboardTableDto[] = [] ;

  timeSubscribe !: Subscription;
  searchText: string = '';

  resultsLength = 0;

  @ViewChild(MatPaginator)
  paginator !: MatPaginator;


  constructor(private dashboardService: DashboardServicesService, public dialog: MatDialog,
    private _snackBar: MatSnackBar ) { }


  ngAfterViewInit(): void {
    this.getOrReload(this.paginator.pageIndex, this.paginator.pageSize);
  }

  onPaginationChange(event: any) {
    this.getOrReload(this.paginator.pageIndex, this.paginator.pageSize);
  }


  ngOnDestroy(): void {
    /*  
     if( this.timeSubscribe != undefined ){
      this.timeSubscribe.unsubscribe();
    }   
    */
  }


  ngOnInit(): void {

    this.alldeleted();
    // this.getOrReload(this.nr - 1, 3);

    this.form = new FormGroup({
      name: new FormControl(null, [Validators.required]),
      description: new FormControl(null)
    });

    this.filtercontainer = new FormGroup({
      filter: new FormControl(null)
    });

  }


  submitForm() {
    // console.log(this.form.getRawValue());
    // console.log(this.form); 
    this.form.controls['name'].markAsUntouched ;

    this.errmsg = false;
    this.errorMesage = '';

    const dashboardPost: DashboardPostDto = {
      name: this.form.get('name')?.value,
      description: this.form.get('description')?.value
    }

    this.dashboardService.addDashboard(dashboardPost)
      .subscribe(() => {
        this.paginator.pageIndex = 0 ;
        this.getOrReload(this.paginator.pageIndex, this.paginator.pageSize);

        let dashboard = {
          name: ' ' ,
          description: null
        }

        this.form.setValue(dashboard);
      },
        (error: HttpErrorResponse) => {
         // console.log('error : ', error.error.localizedMessage);
         console.log('error ');
         
          this.form.controls['name'].markAsTouched ;

          this.errmsg = true;
          this.errorMesage = error.error.localizedMessage;
          this.form.get('name')?.setValue('');
        });
  }


  getOrReload(page: number, size: number) {

    this.statusColor = 'green' ;
    this.connectionText = 'connected';

    this.dashboardService.getAllDashboards(page, size)
      .subscribe(res => {

        //console.log('res : ', res);
        // this.paginator.length = res.totalElements;
        this.resultsLength = res.totalElements;
        const arr = [];

        for (let el of res.content) {
          arr.push(el);
        }
        this.dataSource = new MatTableDataSource(arr);
      }, error =>{ 
        this.statusColor = 'red' ;
        this.connectionText = 'disconnected';
      });
  }

  updating(id: string) {
    

    this.dashboardService.getDashboardById(id)
      .subscribe(data => {

        this.id = data.id;

        let dashboard = {
          name: data.name,
          description: data.description
        }

        this.form.setValue(dashboard);

        this.edit = 'block';
        this.add = 'none';
      });

  }

  deleting(id: string) {

    this.removeItem(id);
  }

  removeItem(id: string) {

      const dialogRef = this.dialog.open(DeleteDialogeComponent, {
        //height: '20vh',
        //width: '20vw',
        data: { name : "If you click continue it will be removed permanetly." }  ,
        panelClass: 'custom-modalbox'
      });
  
      dialogRef.afterClosed()
        .subscribe(confirmation => {
          if (confirmation) {
            this.dashboardService.deleteDashboard(id)
            .subscribe(() => {
      
              this.paginator.pageIndex = 0 ;
      
              this.getOrReload(this.paginator.pageIndex, this.paginator.pageSize);
              this.show = 'block';
              this.alldeleted();
            });
          }
        });


  }


  editDashboard() {

    this.errmsg = false;
    this.errorMesage = '';

    const dashboard: DashboardTableDto = {
      id: this.id,
      name: this.form.get('name')?.value,
      description: this.form.get('description')?.value,
    }

    this.dashboardService.modyfieDashboard(this.id, dashboard)
      .subscribe(() => {

        this.edit = 'none';
        this.add = 'block';

        this.paginator.pageIndex = 0 ;

        this.getOrReload(this.paginator.pageIndex, this.paginator.pageSize);

        let dashboard = {
          name:  ' ',
          description: null
        }

        this.form.setValue(dashboard);
      },
        (error: HttpErrorResponse) => {
          this.errmsg = true;
          this.errorMesage = error.error.localizedMessage;
          this.form.get('name')?.setValue('');
        });

  }

  cancelDashboard() {

    this.errmsg = false;
    this.errorMesage = '';

    let dashboard = {
      name: null,
      description: null
    }

    this.form.setValue(dashboard);
  }


  intervalFilter() {
    this.timeSubscribe = source.subscribe(val => {
      this.applyFilter();
    });
  }

  applyFilter() {
    if (this.filtercontainer.get('filter')?.value == this.searchText) {
      // this.timeSubscribe.unsubscribe();
    } else {
      if (this.filtercontainer.get('filter')?.value != null) {
        this.searchText = this.filtercontainer.get('filter')?.value;
        this.applyFilterDB(this.searchText);
      }
    }

  }

  applyFilterDB(filterValue: string) { // event: Event
    this.statusColor = 'green' ;
    this.connectionText = 'connected';

    this.filtered = true;
    this.paginator.pageIndex = 0 ;

    // const filterValue = (event.target as HTMLInputElement).value;
    this.dashboardService.filterDashboards(filterValue.trim().toLowerCase(), this.paginator.pageIndex, this.paginator.pageSize)
      .subscribe(res => {
        const arr = [];

        for (let el of res.content) {
          arr.push(el);
        }
        this.dataSource = new MatTableDataSource(arr);
      }, error => { 
        this.statusColor = 'red' ;
        this.connectionText = 'disconnected';
      });
  }



  revertDelete(id: string) {
    this.dashboardService.revertDelete(id)
      .subscribe(() => {
       this.paginator.pageIndex = 0 ;
       this.getOrReload(this.paginator.pageIndex, this.paginator.pageSize);
       this.alldeleted();
      });
  }


  alldeleted() {
    this.statusColor = 'green' ;
    this.connectionText = 'connected';

    this.dashboardService.getAllDeletedDashboards()
      .subscribe(data => {
        this.deleteDashboards = data;
      }, error =>{ 
        this.statusColor = 'red' ;
        this.connectionText = 'disconnected';
       });
  }

  hardDelete(id: string) {

    const dialogRef = this.dialog.open(DeleteDialogeComponent, {
      height: '20vh',
      width: '20vw',
      data: { name : "If you click continue it will be removed permanetly." }  ,
      panelClass: 'custom-modalbox'
    });

    dialogRef.afterClosed()
      .subscribe(confirmation => {
        if (confirmation) {

          this.dashboardService.hardDeleteDashboard(id)
            .subscribe(res => {
              this.alldeleted();
              // console.log('deleted pop up')
            },
              (error: HttpErrorResponse) => {
                console.log('error : ', error.error.localizedMessage );

                this._snackBar.open(error.error.localizedMessage , '', {
                  duration: 3000,
                  horizontalPosition: 'end',
                  verticalPosition: 'top',
                  panelClass: 'error-modalbox'
                });

                /*
                const dialogRef = this.dialog.open(ErrorComponent, {
                  height: '25vh',
                  width: '35vw',
                  data: {
                    name: error.error.localizedMessage
                  },
                  panelClass: 'error-modalbox'
                });
                */

              });

        }
      });
  }


}
