import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { WidgetComponent } from '../../dumy/widget/widget.component';
import { DashboardServicesService } from '../../services/dashboard-services.service';
import { WidgetService } from '../../services/widget.service';
import { DisplayGrid, CompactType, GridsterConfig, GridsterItem, GridsterItemComponent, GridsterPush, GridType } from 'angular-gridster2';
import { EditWidgetComponent } from '../../dumy/edit-widget/edit-widget.component';
import { WebSocketServiceService } from '../../services/web-socket-service.service';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { InformationData } from '../../interfaces/informationData.interface';
import { TimeFilter } from '../../interfaces/timeFilter.interface';
import { DeleteDialogeComponent } from '../../dumy/delete-dialoge/delete-dialoge.component';
import { HttpErrorResponse } from '@angular/common/http';
import { WorldmapComponent } from '../../dumy/worldmap/worldmap.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ChartStructure } from '../../interfaces/chartStructure.interface';
import { WidgetDto } from '../../interfaces/widgetDto.interface';
import { loadavg } from 'os';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {

  id !: string;
  dashboardName !: string;

  options!: GridsterConfig;
  dashboard: GridsterItem[] = [];
  itemToPush!: GridsterItemComponent;

  // chartStructure !: ChartStructure;

  stompClient: any;

  statusColor: string = 'green';
  connectionText: string = 'connected';

  // chart option
  barChartOptions: ChartOptions = {
    responsive: true,
    maintainAspectRatio: true
  };

  barChartLegend = true;
  barChartPlugins = [];

  lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: ['aliceblue', 'aqua', 'blue', 'blueviolet', 'cadetblue', 'brown', 'darkblue', 'gold', 'greenyellow', 'green', 'darkgreen', 'darkorange', 'darkslategray',
        '#4040d0fa', '#acacc5fa', '#bd1d93fa', '#6b0d0dfa', '#da6d6dfa', '#241a2ffa', '#7eda6dfa',
        '#16520bfa', '#1d2f1afa', '#bd6011fa', '#057939', 'crimson', 'coral', 'turquoise', 'chocolate', 'forestgreen', 'white'], // 'rgba(255,255,0,0.28)',
      pointBorderColor: 'white',
      pointBorderWidth: 5,
      // pointHoverBackgroundColor : 'green',
      pointHoverBorderColor: 'teal',
      hoverBackgroundColor: 'teal',
      hoverBorderColor: 'teal'
    },
  ];


  timeArray: TimeFilter[] = [
    {
      timeText: 'None',
      timeValue: '0'
    },
    {
      timeText: 'Before 5 min',
      timeValue: '5'
    },

    {
      timeText: 'Before 10 min',
      timeValue: '10'
    },

    {
      timeText: 'Before 15 min',
      timeValue: '15'
    },

    {
      timeText: 'Before half hour',
      timeValue: '30'
    },

    {
      timeText: 'Before 45 min',
      timeValue: '45'
    },

    {
      timeText: 'Before a hour',
      timeValue: '60'
    },

    {
      timeText: 'Before 1 hour a half ',
      timeValue: '90'
    },

    {
      timeText: 'Before 2 hour',
      timeValue: '120'
    }
  ];


  constructor(private webSocket: WebSocketServiceService, private widgetService: WidgetService,
    private dashboardService: DashboardServicesService, private route: ActivatedRoute,
    public dialog: MatDialog, private _snackBar: MatSnackBar) { }


  ngOnDestroy(): void {

    this.stompClient.disconnect(() => {
      console.log('disconected');
    });

    //this.dashboardService.setWebSocketDisconnect(this.id)
    //  .subscribe();
  }


  ngOnInit(): void {

    this.options = {
      //gridType: GridType.Fit,
      //compactType: CompactType.None,
      pushItems: true,
      displayGrid: DisplayGrid.None,
      defaultItemRows: 10,
      defaultItemCols: 10,
      margin: 30,
      outerMargin: true,
      outerMarginTop: 30,
      outerMarginRight: 30,
      outerMarginBottom: 30,
      outerMarginLeft: 30,
      swap: false,
      draggable: {
        enabled: true,
      },
      resizable: {
        enabled: true
      }
    };

    this.id = this.route.snapshot.paramMap.get('id') as string;

    this.dashboardService.getOneDashboard(this.id)
      .subscribe(data => {
        this.statusColor = 'green';
        this.connectionText = 'connected';
        this.dashboardName = data.name;
      }, (error: HttpErrorResponse) => {
        this.statusColor = 'red';
        this.connectionText = 'disconnected';
      });

    this.dashboardOpened();
    this.getAllWidgets(this.id);

    this.stompClient = this.webSocket.connect();
    this.webSocketConect();

  }

  webSocketConect() {

    this.statusColor = 'green';
    this.connectionText = 'connected';

    // Error mesages of stomp
    this.stompClient.connect({}, (frame: any) => {

      this.widgetService.getAllDashboardWidgets(this.id)
      .subscribe( ( res : WidgetDto[] ) => {
        for(let widdto of res ){
          this.widgetService.activateWidget( widdto.id as string , this.id )
          .subscribe(); 
        }
      })

      // Subscribe to notification topic
      this.stompClient.subscribe('/topic/notification' + this.id, (notifications: any) => {
        this.statusColor = 'green';
        this.connectionText = 'connected';
        
        let incomingMsg = JSON.parse(notifications.body);
        // console.log('incomingMsg : ', incomingMsg);
 
        /* 
        for (let db of this.dashboard) {
          if (db.id == incomingMsg.id) {
            console.log('db : ', db );
            
            const index = this.dashboard.indexOf(db);
            this.dashboard.splice(index, 1);

            // this.dashboard.length = 0;

            const chartStructure: ChartStructure = {
              cols: incomingMsg.cols,

              rows: incomingMsg.rows,

              x: incomingMsg.x,

              y: incomingMsg.y,

              charttype: incomingMsg.chartType,
              chartDataSets: [],
              name: incomingMsg.name,
              id: incomingMsg.id,
              labels: [],
              apiData : incomingMsg 
            };

            const dataArr: any[] = [];
            const nameArr: any[] = [];

            for (let el of incomingMsg.informationDataList) {
              dataArr.push(el.value);
              nameArr.push(el.name);
            }

            incomingMsg.informationValues = dataArr;
            incomingMsg.labels = nameArr;

            chartStructure.labels = nameArr;
            (chartStructure.chartDataSets as any[]).push({ data: dataArr, label: incomingMsg.datalabel });
            
            this.dashboard.push(chartStructure);

          }
        }

        */

        for (let db of this.dashboard) {
          if (db.id == incomingMsg.id) {
            
            // console.log('db : ', db );
           /* 
            const index = this.dashboard.indexOf(db);
            this.dashboard.splice(index, 1);

            // this.dashboard.length = 0;

            const chartStructure: ChartStructure = {
              cols: incomingMsg.cols,

              rows: incomingMsg.rows,

              x: incomingMsg.x,

              y: incomingMsg.y,

              charttype: incomingMsg.chartType,
              chartDataSets: [],
              name: incomingMsg.name,
              id: incomingMsg.id,
              labels: [],
              apiData : incomingMsg 
            };

            const dataArr: any[] = [];
            const nameArr: any[] = [];

            for (let el of incomingMsg.informationDataList) {
              dataArr.push(el.value);
              nameArr.push(el.name);
            }

            incomingMsg.informationValues = dataArr;
            incomingMsg.labels = nameArr;

            chartStructure.labels = nameArr;
            (chartStructure.chartDataSets as any[]).push({ data: dataArr, label: incomingMsg.datalabel });
            
            this.dashboard.push(chartStructure);

            */
            // console.log('charttype : ', incomingMsg.chartType  );
            
            db.charttype = incomingMsg.chartType ;

            // console.log('id : ', incomingMsg.id);
            db.id = incomingMsg.id ;

            // console.log('labels : ', incomingMsg.labels );

            if( incomingMsg.labels != undefined ){
              db.labels = incomingMsg.labels ;
            }
           

            // console.log('name : ', incomingMsg.name );
            db.name = incomingMsg.name ;

            // console.log('apidata ');
            db.apiData = incomingMsg ;

            const dataArr: any[] = [];
            const nameArr: any[] = [];

            // console.log('for ');

            for (let el of incomingMsg.informationDataList) {
              dataArr.push(el.value);
              nameArr.push(el.name);
            }

            db.labels = nameArr ;

            // console.log('chartdataset : ', dataArr.length, ' incomingMsg.datalabe : ', incomingMsg.datalabel  );
            db.chartDataSets = [{ data: dataArr, label: incomingMsg.datalabel }];

          }
        }

        
      }, (error: any) => {
        this.statusColor = 'red';
        this.connectionText = 'disconnected';
      })
    },
      (error: any) => {
        this.statusColor = 'red';
        this.connectionText = 'disconnected';
      });

  }

  saveWidgetConfiguration() {
    this.statusColor = 'green';
    this.connectionText = 'connected';

    console.log( 'this.dashboard : ', this.dashboard );
    const widgetDtoList : WidgetDto[] = [] ;

    for(let el of this.dashboard ){

      const widgetDto : WidgetDto = {
        cols: el.cols,

        rows: el.rows,
      
        x: el.x,
      
        y: el.y,
        id: el.id ,
        name: el.name,
        dashboardId : this.id,

        dataSource: el.apiData.dataSource,
        description: el.apiData.description,
        frontFrequency: el.apiData.frontFrequency ,
        informationDataList : el.apiData.informationDataList ,
        charttype : el.apiData.charttype,
        datalabel : el.datalabel
      }

      widgetDtoList.push(widgetDto);
    }

    this.widgetService.saveWidgetConfiguration( widgetDtoList ) // this.dashboard
      .subscribe(res => {
        this.dashboard.length = 0;
        this.getAllWidgets(this.id);
      },
        (error: HttpErrorResponse) => {
          this.statusColor = 'red';
          this.connectionText = 'disconnected';
          console.log('error : ', error.error);

          this._snackBar.open(error.error.localizedMessage, '', {
            duration: 3000,
            horizontalPosition: 'end',
            verticalPosition: 'top',
            panelClass: 'error-modalbox'
          });
        });
  }

  dashboardOpened() {
    this.statusColor = 'green';
    this.connectionText = 'connected';

    this.dashboardService.setDashboardOpened(this.id)
      .subscribe(res => { }, error => { this.statusColor = 'red'; });
  }

  createWidget() {

    const dialogRef = this.dialog.open(WidgetComponent, {
      data: this.id,
      panelClass: 'widget-modalbox'
    });

    dialogRef.afterClosed()
      .subscribe(confirmation => {
        if (confirmation) {
          this.getAllWidgets(this.id);
        }
      });
  }

  getAllWidgets(id: string) {
    this.statusColor = 'green';
    this.connectionText = 'connected';

    this.widgetService.getAllDashboardWidgets(id)
      .subscribe( ( res : WidgetDto[] ) => {

        console.log('getAllWidgets  res : ', res);
        this.dashboard.length = 0;

        for (let el of res) {

          const chartStructure : ChartStructure = {
            cols: el.cols,

            rows: el.rows,

            x: el.x,

            y: el.y,

            charttype: el.charttype,
            chartDataSets: [],
            name: el.name,
            id: el.id,
            labels: [],
            apiData : el ,
            datalabel : el.datalabel
          };

          const dataArr = [];
          const nameArr = [];

          for (let idl of el.informationDataList as InformationData[]) {
            dataArr.push(idl.value);
            nameArr.push(idl.name);
          }

         // el.informationValues = dataArr;
         // el.labels = nameArr;

        //  el.chartDataSets = [];
        //  el.chartDataSets.push({ data: dataArr, label: el.datalabel });


          chartStructure.labels = nameArr;
          //(chartStructure.chartDataSets as any[]).push({ data: dataArr, label: el.datalabel });

          chartStructure.chartDataSets?.push({ data: dataArr, label: el.datalabel });

          // console.log( 'chartStructure : ', chartStructure );
          
          // this.dashboard.push(el);
          this.dashboard.push(chartStructure);
          // this.dashboard.push( { cols: el.cols, rows: el.rows, y: el.y, x: el.x, id: el.id, name : el.name } );
          // console.log( 'after push : ', this.dashboard );
          
        }
        
      }, 
      ( error : HttpErrorResponse ) => {
        this.statusColor = 'red';
        this.connectionText = 'disconnected';
      });

  }

  /* 
  getItemComponent(): void {
    if (this.options.api && this.options.api.getItemComponent) {
      console.log(this.options.api.getItemComponent(this.dashboard[0]));
    }
  }
 */

  removeItem($event: MouseEvent | TouchEvent, item: any): void {

    const dialogRef = this.dialog.open(DeleteDialogeComponent, {
      data: { name: "If you click continue it will be removed permanetly." },
      panelClass: 'custom-modalbox'
    });

    dialogRef.afterClosed()
      .subscribe(confirmation => {
        if (confirmation) {
          this.widgetService.widgetDelete(item.id)
            .subscribe(res => {
              $event.preventDefault();
              $event.stopPropagation();
              this.dashboard.splice(this.dashboard.indexOf(item), 1);
            });
        }
      });
  }

  editItem($event: MouseEvent | TouchEvent, item: any): void {

    const dialogRef = this.dialog.open(EditWidgetComponent, {
      data: { name: item.id },
      panelClass: 'widget-modalbox'
    });

    dialogRef.afterClosed()
      .subscribe(confirmation => {
        if (confirmation) {
          this.getAllWidgets(this.id);
        }
      });
  }

  getTimeFilterValue(timeValue: string) {
    this.widgetService.setTimeFilterChart(this.id, timeValue)
      .subscribe();
  }

  worldMap($event: MouseEvent | TouchEvent, item: any) {
    console.log('item : ', item);

    const dialogRef = this.dialog.open(WorldmapComponent, {
      height: '50vh',
      width: '50vw',
      data: { name: ' data to pass' },
      // panelClass: 'widget-modalbox'
    });


  }

}
