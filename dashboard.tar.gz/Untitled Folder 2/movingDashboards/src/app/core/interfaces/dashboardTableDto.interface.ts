export interface DashboardTableDto{

    id : string,
    name: string,
    description: string,
}