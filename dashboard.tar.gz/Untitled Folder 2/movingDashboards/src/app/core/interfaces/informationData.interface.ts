export interface InformationData {

    name: string,

    localDateTime?: any;

    value: number,

    dataType: string,

}