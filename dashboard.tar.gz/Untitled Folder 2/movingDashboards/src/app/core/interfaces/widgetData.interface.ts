import { InformationData } from "./informationData.interface";

export interface WidgetData {
    id: string,
    informationDataList: InformationData[]
}