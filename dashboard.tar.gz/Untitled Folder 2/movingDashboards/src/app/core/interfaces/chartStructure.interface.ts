import { InformationData } from "./informationData.interface";
import { WidgetDto } from "./widgetDto.interface";

export interface ChartStructure{

    id?: string,
    charttype: string,
    dashboardId ?: string,
    dataSource ?: string,
    description ?: string,
    frontFrequency ?: number,
    name: string,
  
    cols: number,
  
    rows: number,
  
    x: number,
  
    y: number,
  
    informationDataList ?: InformationData[] ,
  
    // e shtuar
    informationValues ?: number[] ,
    labels ?: string[] , 
    chartDataSets ? : any[], // ChartDataSets[],
  
    barChartType ?: any, // ChartType
    datalabel ? : string

    apiData ?: WidgetDto
}