export interface TimeFilter{
    timeText : string
    timeValue : string
}