import { ChartDataSets, ChartType } from "chart.js";
import { InformationData } from "./informationData.interface";

export interface WidgetDto {

  id?: string,
  charttype: string,
  dashboardId: string,
  dataSource: string,
  description: string,
  frontFrequency: number,
  name: string,

  cols: number,

  rows: number,

  x: number,

  y: number,
  datalabel ? : string,

  informationDataList ?: InformationData[] ,


  // e shtuar
 // informationValues ?: number[] ,
  //labels ?: string[] , 
 // chartDataSets ? : any[], // ChartDataSets[],

 // barChartType ?: any // ChartType
  
}

