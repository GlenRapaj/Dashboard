export interface DashboardPostDto {
    name: string,

    description: string,
}