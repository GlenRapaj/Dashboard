import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-errorpopup',
  templateUrl: './errorpopup.component.html',
  styleUrls: ['./errorpopup.component.scss']
})
export class ErrorpopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
