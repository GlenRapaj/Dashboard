import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingDashboardComponent } from './existing-dashboard.component';

describe('ExistingDashboardComponent', () => {
  let component: ExistingDashboardComponent;
  let fixture: ComponentFixture<ExistingDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExistingDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
