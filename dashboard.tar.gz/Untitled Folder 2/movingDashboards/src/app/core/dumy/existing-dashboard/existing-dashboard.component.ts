import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing-dashboard',
  templateUrl: './existing-dashboard.component.html',
  styleUrls: ['./existing-dashboard.component.scss']
})
export class ExistingDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
