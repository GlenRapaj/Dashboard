import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { WidgetService } from '../../services/widget.service';

@Component({
  selector: 'app-widget',
  templateUrl: './widget.component.html',
  styleUrls: ['./widget.component.scss']
})
export class WidgetComponent implements OnInit {

  form !: FormGroup;
  Charttypes !: string[];
  matcher = new ErrorStateMatcher();
  selected : string = '' ;

  nameerrorMesage : string = '';
  nameerr : boolean = false ;

  dataSrcErrorMesage : string = '';
  dataSrc : boolean = false ;

  creTypeErrorMesage : string = '';
  creType : boolean = false ;

  dataLabels : string[] = [ 'air preasure', 'temperature', 'co2 emision', 'rain percipitation'] ;
  dataCat : string = '';

  constructor( private router: Router,private widgetService : WidgetService, 
    public fb: FormBuilder, @Inject(MAT_DIALOG_DATA) public data: { name: string } ) { }

  ngOnInit(): void {

    this.Charttypes = ['pie', 'bar', 'line'];
    // 
    // registrationForm 
    this.form = this.fb.group({
      name: new FormControl(null, [Validators.required]),
      description: new FormControl(null),
      dataSource: new FormControl('Data source url', [Validators.required] ),
      dashboardId: new FormControl(null),
      frontFrequency: new FormControl(null, [Validators.required]),
      charttype: new FormControl(null, [Validators.required] ),
      datalabel : new FormControl(null, [Validators.required] )
    });

    this.form.controls['dataSource'].disable() ;

  }

  submitForm() {
    // console.log(this.form.getRawValue());
    // console.log(this.form); 
    this.form.get('dashboardId')?.setValue( this.data );

    this.widgetService.addWidget( this.form.getRawValue() )
    .subscribe( ()=>{
      // this.router.navigateByUrl("/dashboard/" + this.data );
      let btn = document.getElementById("ok-btn");
      btn?.click();
    },
    ( error : HttpErrorResponse )=>{
      // console.log( 'error : ', error.error.localizedMessage );

      if( error.error.localizedMessage.toLowerCase().trim().includes('widget name') ){
        console.log( 'widget name error : ', error.error.localizedMessage ); 

        this.form.controls['name'].markAsTouched ;
        this.nameerrorMesage = error.error.localizedMessage ;
        this.form.get('name')?.setValue('');
        this.nameerr = true ;
      }

      if( error.error.localizedMessage.toLowerCase().trim().includes('chart type') ){
        console.log( 'chart type error : ', error.error.localizedMessage ); 

        this.form.controls['charttype'].markAsTouched ;
        this.creTypeErrorMesage = error.error.localizedMessage ;
        this.form.get('charttype')?.setValue('');
        this.creType = true ;
      }

      if( error.error.localizedMessage.toLowerCase().trim().includes('data source') ){
        console.log( 'data source error : ', error.error.localizedMessage ); 

        this.form.controls['dataSource'].markAsTouched ;
        this.dataSrcErrorMesage = error.error.localizedMessage ;
        this.form.get('dataSource')?.setValue('');
        this.dataSrc = true ;
      }
      
    });
  }




}
