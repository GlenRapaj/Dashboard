import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-dialoge',
  templateUrl: './delete-dialoge.component.html',
  styleUrls: ['./delete-dialoge.component.scss']
})
export class DeleteDialogeComponent implements OnInit {

  constructor( @Inject(MAT_DIALOG_DATA) public data: {name : string} ) { }

  ngOnInit(): void {
    // console.log( this.data.name )
  }

}
