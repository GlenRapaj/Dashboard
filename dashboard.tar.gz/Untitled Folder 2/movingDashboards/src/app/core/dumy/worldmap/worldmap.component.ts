import { Component, OnInit } from '@angular/core';


declare const L: any;


@Component({
  selector: 'app-worldmap',
  templateUrl: './worldmap.component.html',
  styleUrls: ['./worldmap.component.scss']
})
export class WorldmapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

    let mymap = L.map('mapid').setView([  41.336273899999995  , 19.814383600000003 ], 5); // zoom level

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      maxZoom: 18,
      id: 'mapbox/streets-v11',
      tileSize: 512,
      zoomOffset: -1,
      accessToken: 'your.mapbox.access.token'
    }).addTo(mymap);

    // cords.latitude , cords.longitude
    var marker = L.marker([  41.336273899999995  , 19.814383600000003 ]).addTo(mymap);  // cordinatat
    var marker1 = L.marker([  41.50  , 19.90 ]).addTo(mymap);  // cordinatat
    var marker2 = L.marker([  41.80  , 19.70 ]).addTo(mymap);  // cordinatat
  }

}



/*

    navigator.geolocation.getCurrentPosition(position => {
      
      console.log(position);

      const cords = position.coords;

      let mymap = L.map('mapid').setView([cords.latitude, cords.longitude], 13); // zoom level

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'your.mapbox.access.token'
      }).addTo(mymap);

            // cords.latitude , cords.longitude
      var marker = L.marker([  41.336273899999995  , 19.814383600000003 ]).addTo(mymap);  // cordinatat

    });

*/
