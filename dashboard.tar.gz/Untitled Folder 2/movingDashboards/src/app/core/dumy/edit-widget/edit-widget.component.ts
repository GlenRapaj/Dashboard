import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { WidgetDto } from '../../interfaces/widgetDto.interface';
import { WidgetService } from '../../services/widget.service';

@Component({
  selector: 'app-edit-widget',
  templateUrl: './edit-widget.component.html',
  styleUrls: ['./edit-widget.component.scss']
})
export class EditWidgetComponent implements OnInit {

  form !: FormGroup;
  Charttypes !: string[];
  matcher = new ErrorStateMatcher();

  nameerrorMesage : string = '';
  nameerr : boolean = false ;

  dataSrcErrorMesage : string = '';
  dataSrc : boolean = false ;

  creTypeErrorMesage : string = '';
  creType : boolean = false ;

  
  selected : string = '' ;

  widgetDto !: WidgetDto ;

  dataLabels : string[] = [ 'air preasure', 'temperature', 'co2 emision', 'rain percipitation'] ;
  dataCat : string = '';
  
  constructor( private router: Router,private widgetService : WidgetService, 
    public fb: FormBuilder, @Inject(MAT_DIALOG_DATA) public data: { name: string } ) { }

  ngOnInit(): void {

    this.Charttypes = ['pie', 'bar', 'line'];

    // registrationForm 
    this.form = this.fb.group({
      name: new FormControl(null, [Validators.required]),
      description: new FormControl(null),
      dataSource: new FormControl(null, [Validators.required] ),
      dashboardId: new FormControl(null),
      frontFrequency: new FormControl(null, [Validators.required]),
      charttype: new FormControl(null, [Validators.required] ),
      datalabel : new FormControl(null, [Validators.required] )
    });

    this.widgetService.getOneWidget( this.data.name )
    .subscribe( data =>{
      console.log( 'data : ', data );
      this.widgetDto = data ;

      this.form.get('name')?.setValue( data.name );
      this.form.get('description')?.setValue( data.description );
      this.form.get('dataSource')?.setValue( data.dataSource );
      this.form.get('dashboardId')?.setValue( data.dashboardId );
      this.form.get('frontFrequency')?.setValue( data.frontFrequency );
      this.form.get('charttype')?.setValue( data.charttype );
      this.form.get('datalabel')?.setValue( data.datalabel );
      
      this.form.controls['dataSource'].disable() ;
    });
  }

  submitForm() {
    
    this.widgetDto.name = this.form.get('name')?.value ;
    this.widgetDto.description = this.form.get('description')?.value ;
    this.widgetDto.dataSource = this.form.get('dataSource')?.value ;
    this.widgetDto.dashboardId = this.form.get('dashboardId')?.value ;
    this.widgetDto.frontFrequency = this.form.get('frontFrequency')?.value ;
    this.widgetDto.charttype = this.form.get('charttype')?.value ;
    this.widgetDto.datalabel = this.form.get('datalabel')?.value ;

    this.widgetService.modifieWidget( this.widgetDto )
    .subscribe( res=>{
      let btn = document.getElementById("ok-btn");
      btn?.click();
    },
    ( error : HttpErrorResponse )=>{
      // Erroret duhet te pasqyrohen ne forme.
      console.log( 'error : ', error.error.localizedMessage );


      if( error.error.localizedMessage.toLowerCase().trim().includes('widget name') ){
        console.log( 'widget name error : ', error.error.localizedMessage ); 

        this.form.controls['name'].markAsTouched ;
        this.nameerrorMesage = error.error.localizedMessage ;
        this.form.get('name')?.setValue('');
        this.nameerr = true ;
      }

      if( error.error.localizedMessage.toLowerCase().trim().includes('chart type') ){
        console.log( 'chart type error : ', error.error.localizedMessage ); 

        this.form.controls['charttype'].markAsTouched ;
        this.creTypeErrorMesage = error.error.localizedMessage ;
        this.form.get('charttype')?.setValue('');
        this.creType = true ;
      }

      if( error.error.localizedMessage.toLowerCase().trim().includes('data source') ){
        console.log( 'data source error : ', error.error.localizedMessage ); 

        this.form.controls['dataSource'].markAsTouched ;
        this.dataSrcErrorMesage = error.error.localizedMessage ;
        this.form.get('dataSource')?.setValue('');
        this.dataSrc = true ;
      }

      });

  }

}
