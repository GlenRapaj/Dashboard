import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './dumy/error/error.component';
import { DashboardDataComponent } from './main_components/dashboard-data/dashboard-data.component';
import { DashboardComponent } from './main_components/dashboard/dashboard.component';
import { HomeComponent } from './main_components/home/home.component';

const routes: Routes = [
  { path: "", component : HomeComponent, pathMatch : 'full' },
  { path: "dashboard-data", component : DashboardDataComponent },
  { path: "dashboard/:id", component : DashboardComponent },
  { path: "**", component : ErrorComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoreRoutingModule { }
