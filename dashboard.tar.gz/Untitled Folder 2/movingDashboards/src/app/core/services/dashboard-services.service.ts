import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { DashboardPostDto } from '../interfaces/dashboardPostDto.interface';
import { DashboardTableDto } from '../interfaces/dashboardTableDto.interface';




const api_url = 'http://localhost:8080/dashboards/' ;


@Injectable({
  providedIn: 'root'
})
export class DashboardServicesService {

  constructor(private  httpc : HttpClient ) { }

  addDashboard( dp : DashboardPostDto ) : Observable< DashboardPostDto > {
    
    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    }; 

    return this.httpc.post<DashboardPostDto>( `${api_url}add-dashboard`, dp ) ;
  }

  getAllDashboards( page : number, size : number ) : Observable< any > { // DashboardTableDto[]
    return this.httpc.get< any  >( `${api_url}all-dashboards?page=${page}&size=${size}` ) ;
  }

  deleteDashboard( id : string ) : Observable< any >{
    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    }; 

    return this.httpc.delete<any>(`${api_url}delete-dashboard/${id}`, option );
  }

  revertDelete( id : string ): Observable< any >{
    return this.httpc.get<any >( `${api_url}revert-delete/${id}` ) ;
  }

  getDashboardById( id : string ): Observable< DashboardTableDto >{
    return this.httpc.get<any >( `${api_url}one-element/${id}` ) ;
  }

  modyfieDashboard( id : string, dashboard : DashboardTableDto ): Observable< any > {

    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    };

    return this.httpc.put<any>( `${api_url}modyfie-dashboard/${id}`, dashboard, option );
  }

  filterDashboards( name : string, page : number, size : number ) : Observable< any > { //  DashboardTableDto[]
    return this.httpc.get< any >( `${api_url}filter-dashboards/${name}?page=${page}&size=${size}` ) ;
  }


  getAllDeletedDashboards( ) : Observable< DashboardTableDto[] > { // 
    return this.httpc.get< DashboardTableDto[]  >( `${api_url}delete-list` ) ;
  }

  getDashboardByName( name : string ) : Observable< DashboardTableDto >{
    return this.httpc.get< DashboardTableDto >( `${api_url}dashboard-name/${name}` ) ;
  }

  hardDeleteDashboard( id : string ) : Observable< any >{
    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    };
    return this.httpc.delete<any>( `${api_url}hard-delete-dashboard/${id}`, option );
  }

  lastOpenedDashboards() : Observable< any > { // DashboardTableDto[]
    return this.httpc.get< any  >( `${api_url}three-last` ) ;
  }

  setDashboardOpened( id : string ) : Observable< any > { // DashboardTableDto[]
    return this.httpc.get< any  >( `${api_url}opened-dashboard/${id}` ) ;
  }

  getOneDashboard( id : string ) : Observable< any >  {
    return this.httpc.get< any  >( `${api_url}one-dashboard/${id}` ) ;
  }

  /* 
  setWebSocketConnection( id : string ) : Observable< any > {
    return this.httpc.get< any  >( `${api_url}setConnection/${id}` ) ;
  }

  setWebSocketDisconnect( id : string ) : Observable< any > {
    return this.httpc.get< any  >( `${api_url}removeConnection/${id}` ) ;
  }
 */ 



}
