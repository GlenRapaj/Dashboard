import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { WidgetDto } from '../interfaces/widgetDto.interface';


const api_url = 'http://localhost:8080/widgets/' ;


@Injectable({
  providedIn: 'root'
})
export class WidgetService {

  constructor( private  httpc : HttpClient ) { }


  addWidget( widgetDto : WidgetDto ) : Observable< WidgetDto > {
    
    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    }; 

    return this.httpc.post<WidgetDto>( `${api_url}add-widget`, widgetDto ) ;
  }

  getAllDashboardWidgets( id : string ) : Observable< WidgetDto[] >{
    return this.httpc.get<WidgetDto[]>( `${api_url}all-widgets/${id}` );
  }

  saveWidgetConfiguration( widgetDtoList : any[] ) : Observable< any > {

    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    };

    return this.httpc.put<any>( `${api_url}save-configuration`, widgetDtoList, option );
  }

  widgetDelete( id : string ) : Observable< any > {
    return this.httpc.delete< any >(`${api_url}hard-delete-widget/${id}` );
  }

  getOneWidget(  id : string  )  : Observable< WidgetDto > {
    return this.httpc.get<WidgetDto>( `${api_url}get-one-widget/${id}` );
  }

  modifieWidget( widgetDto : WidgetDto ) : Observable< any > {

    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    };

    return this.httpc.put<any>( `${api_url}modified-widget`, widgetDto, option );
  }


  initPushData( id : string ) : Observable< any > {
    return this.httpc.get<any>( `${api_url}dashboard-push-data` );  // /${id}
  }

  setTimeFilterChart( id : string, value : string  ) : Observable< any > {
    return this.httpc.get<any>( `${api_url}date-filter-value/${id}/${value}` );
  }

  activateWidget( wid : string, did : string ) : Observable< any > {
    
    let headers = new HttpHeaders();
    headers.set('content-type', 'application/json' );

    let option = {
      'headers' : headers
    }; 

    return this.httpc.post<any>( `${api_url}activate-widget/${wid}`, did ) ;
  }


}
